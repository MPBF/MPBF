var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// shared/schema.ts
var schema_exports = {};
__export(schema_exports, {
  categories: () => categories,
  correctiveActions: () => correctiveActions,
  createRollSchema: () => createRollSchema,
  customerProducts: () => customerProducts,
  customers: () => customers,
  finalProducts: () => finalProducts,
  insertCategorySchema: () => insertCategorySchema,
  insertCorrectiveActionSchema: () => insertCorrectiveActionSchema,
  insertCustomerProductSchema: () => insertCustomerProductSchema,
  insertCustomerSchema: () => insertCustomerSchema,
  insertFinalProductSchema: () => insertFinalProductSchema,
  insertItemSchema: () => insertItemSchema,
  insertJobOrderSchema: () => insertJobOrderSchema,
  insertMachineSchema: () => insertMachineSchema,
  insertMasterBatchSchema: () => insertMasterBatchSchema,
  insertMixItemSchema: () => insertMixItemSchema,
  insertMixMachineSchema: () => insertMixMachineSchema,
  insertMixMaterialSchema: () => insertMixMaterialSchema,
  insertOrderSchema: () => insertOrderSchema,
  insertQualityCheckSchema: () => insertQualityCheckSchema,
  insertQualityCheckTypeSchema: () => insertQualityCheckTypeSchema,
  insertRawMaterialSchema: () => insertRawMaterialSchema,
  insertRollSchema: () => insertRollSchema,
  insertSectionSchema: () => insertSectionSchema,
  insertSmsMessageSchema: () => insertSmsMessageSchema,
  insertUserSchema: () => insertUserSchema,
  items: () => items,
  jobOrders: () => jobOrders,
  machines: () => machines,
  masterBatches: () => masterBatches,
  mixItems: () => mixItems,
  mixMachines: () => mixMachines,
  mixMaterials: () => mixMaterials,
  orders: () => orders,
  qualityCheckTypes: () => qualityCheckTypes,
  qualityChecks: () => qualityChecks,
  rawMaterials: () => rawMaterials,
  rolls: () => rolls,
  sections: () => sections,
  smsMessages: () => smsMessages,
  users: () => users
});
import { pgTable, text, serial, integer, boolean, timestamp, doublePrecision, unique } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
var categories, insertCategorySchema, items, insertItemSchema, sections, insertSectionSchema, masterBatches, insertMasterBatchSchema, users, insertUserSchema, customers, insertCustomerSchema, customerProducts, insertCustomerProductSchema, orders, insertOrderSchema, jobOrders, insertJobOrderSchema, rolls, insertRollSchema, createRollSchema, machines, insertMachineSchema, rawMaterials, insertRawMaterialSchema, finalProducts, insertFinalProductSchema, qualityCheckTypes, insertQualityCheckTypeSchema, qualityChecks, insertQualityCheckSchema, correctiveActions, insertCorrectiveActionSchema, smsMessages, insertSmsMessageSchema, mixMaterials, mixMachines, insertMixMaterialSchema, insertMixMachineSchema, mixItems, insertMixItemSchema;
var init_schema = __esm({
  "shared/schema.ts"() {
    "use strict";
    categories = pgTable("categories", {
      id: text("id").primaryKey(),
      // CID in the provided schema
      name: text("name").notNull(),
      // Category Name
      code: text("code").notNull().unique()
      // Category Code
    });
    insertCategorySchema = createInsertSchema(categories);
    items = pgTable("items", {
      id: text("id").primaryKey(),
      // ItemID
      categoryId: text("category_id").notNull().references(() => categories.id),
      // CategoriesID
      name: text("name").notNull(),
      // Items Name
      fullName: text("full_name").notNull()
      // Item Full Name
    });
    insertItemSchema = createInsertSchema(items);
    sections = pgTable("sections", {
      id: text("id").primaryKey(),
      // Section ID
      name: text("name").notNull()
      // Section Name
    });
    insertSectionSchema = createInsertSchema(sections);
    masterBatches = pgTable("master_batches", {
      id: text("id").primaryKey(),
      // MasterBatch ID
      name: text("name").notNull()
      // Master Batch
    });
    insertMasterBatchSchema = createInsertSchema(masterBatches);
    users = pgTable("users", {
      id: text("id").primaryKey(),
      // UID
      username: text("username").notNull().unique(),
      // UserName
      password: text("password").notNull(),
      name: text("name").notNull(),
      // UserName (display name)
      role: text("role").notNull(),
      // UserRole
      isActive: boolean("is_active").default(true),
      sectionId: text("section_id").references(() => sections.id)
      // UserSection
    });
    insertUserSchema = createInsertSchema(users).omit({ id: true });
    customers = pgTable("customers", {
      id: text("id").primaryKey(),
      // CID
      code: text("code").notNull().unique(),
      // Customer Code
      name: text("name").notNull(),
      // Customer Name
      nameAr: text("name_ar"),
      // Customer Name Ar
      userId: text("user_id").references(() => users.id),
      // UserID (Sales)
      plateDrawerCode: text("plate_drawer_code")
      // Plate Drawer Code
    });
    insertCustomerSchema = createInsertSchema(customers);
    customerProducts = pgTable("customer_products", {
      id: serial("id").primaryKey(),
      // CPID
      customerId: text("customer_id").notNull().references(() => customers.id),
      // Customer ID
      categoryId: text("category_id").notNull().references(() => categories.id),
      // CategoryID
      itemId: text("item_id").notNull().references(() => items.id),
      // ItemID
      sizeCaption: text("size_caption"),
      // Size Caption
      width: doublePrecision("width"),
      // Width
      leftF: doublePrecision("left_f"),
      // Left F
      rightF: doublePrecision("right_f"),
      // Right F
      thickness: doublePrecision("thickness"),
      // Thickness
      thicknessOne: doublePrecision("thickness_one"),
      // Thickness One
      printingCylinder: doublePrecision("printing_cylinder"),
      // Printing Cylinder (Inch)
      lengthCm: doublePrecision("length_cm"),
      // Length (Cm)
      cuttingLength: doublePrecision("cutting_length_cm"),
      // Cutting Length (CM)
      rawMaterial: text("raw_material"),
      // Raw Material
      masterBatchId: text("master_batch_id").references(() => masterBatches.id),
      // Master Batch ID
      printed: text("printed"),
      // Printed
      cuttingUnit: text("cutting_unit"),
      // Cutting Unit
      unitWeight: doublePrecision("unit_weight_kg"),
      // Unit Weight (Kg)
      packing: text("packing"),
      // Packing
      punching: text("punching"),
      // Punching
      cover: text("cover"),
      // Cover
      volum: text("volum"),
      // Volum
      knife: text("knife"),
      // Knife
      notes: text("notes")
      // Notes
    }, (table) => {
      return {
        customerProductUnique: unique().on(table.customerId, table.itemId)
      };
    });
    insertCustomerProductSchema = createInsertSchema(customerProducts).omit({ id: true });
    orders = pgTable("orders", {
      id: serial("id").primaryKey(),
      // ID
      date: timestamp("date").defaultNow().notNull(),
      // Order Date
      customerId: text("customer_id").notNull().references(() => customers.id),
      // Customer ID
      note: text("note"),
      // Order Note
      status: text("status").notNull().default("pending"),
      // Status (pending, processing, completed)
      userId: text("user_id").references(() => users.id)
      // Created by
    });
    insertOrderSchema = createInsertSchema(orders).omit({ id: true, date: true, status: true });
    jobOrders = pgTable("job_orders", {
      id: serial("id").primaryKey(),
      // ID
      orderId: integer("order_id").notNull().references(() => orders.id),
      // Order ID
      customerProductId: integer("customer_product_id").notNull().references(() => customerProducts.id),
      // Customer Product No
      quantity: doublePrecision("quantity").notNull(),
      // Qty Kg
      status: text("status").default("pending").notNull(),
      // Status (pending, in_progress, extrusion_completed, completed, cancelled)
      customerId: text("customer_id").references(() => customers.id)
      // Customer ID
    }, (table) => {
      return {
        jobOrderUnique: unique().on(table.orderId, table.customerProductId)
      };
    });
    insertJobOrderSchema = createInsertSchema(jobOrders).omit({ id: true });
    rolls = pgTable("rolls", {
      id: text("id").primaryKey(),
      // ID
      jobOrderId: integer("job_order_id").notNull().references(() => jobOrders.id),
      // Job Order ID
      serialNumber: text("roll_serial").notNull(),
      // Roll Serial
      extrudingQty: doublePrecision("extruding_qty").default(0),
      // Extruding Qty
      printingQty: doublePrecision("printing_qty").default(0),
      // Printing Qty
      cuttingQty: doublePrecision("cutting_qty").default(0),
      // Cutting Qty
      currentStage: text("current_stage").notNull().default("extrusion"),
      // Current stage (extrusion, printing, cutting, completed)
      status: text("status").notNull().default("pending"),
      // Status (pending, processing, completed)
      wasteQty: doublePrecision("waste_qty").default(0),
      // Waste quantity in kg (difference between printing and cutting)
      wastePercentage: doublePrecision("waste_percentage").default(0),
      // Waste percentage
      createdById: text("created_by_id").references(() => users.id),
      // User who created the roll (extrusion)
      printedById: text("printed_by_id").references(() => users.id),
      // User who printed the roll
      cutById: text("cut_by_id").references(() => users.id),
      // User who cut the roll
      createdAt: timestamp("created_at").defaultNow(),
      // Creation timestamp
      printedAt: timestamp("printed_at"),
      // Printing timestamp
      cutAt: timestamp("cut_at")
      // Cutting timestamp
    });
    insertRollSchema = createInsertSchema(rolls);
    createRollSchema = insertRollSchema.omit({
      id: true,
      serialNumber: true
    });
    machines = pgTable("machines", {
      id: text("id").primaryKey(),
      name: text("name").notNull(),
      sectionId: text("section_id").references(() => sections.id),
      isActive: boolean("is_active").default(true)
    });
    insertMachineSchema = createInsertSchema(machines);
    rawMaterials = pgTable("raw_materials", {
      id: serial("id").primaryKey(),
      name: text("name").notNull(),
      type: text("type").notNull(),
      quantity: doublePrecision("quantity").default(0),
      unit: text("unit").notNull(),
      lastUpdated: timestamp("last_updated").defaultNow()
    });
    insertRawMaterialSchema = createInsertSchema(rawMaterials).omit({ id: true, lastUpdated: true });
    finalProducts = pgTable("final_products", {
      id: serial("id").primaryKey(),
      jobOrderId: integer("job_order_id").notNull().references(() => jobOrders.id),
      quantity: doublePrecision("quantity").notNull(),
      completedDate: timestamp("completed_date").defaultNow(),
      status: text("status").notNull().default("in-stock")
    });
    insertFinalProductSchema = createInsertSchema(finalProducts).omit({ id: true, completedDate: true });
    qualityCheckTypes = pgTable("quality_check_types", {
      id: text("id").primaryKey(),
      name: text("name").notNull(),
      description: text("description"),
      checklistItems: text("checklist_items").array(),
      parameters: text("parameters").array(),
      targetStage: text("target_stage").notNull(),
      // extrusion, printing, cutting, final
      isActive: boolean("is_active").default(true)
    });
    insertQualityCheckTypeSchema = createInsertSchema(qualityCheckTypes);
    qualityChecks = pgTable("quality_checks", {
      id: serial("id").primaryKey(),
      checkTypeId: text("check_type_id").notNull().references(() => qualityCheckTypes.id),
      rollId: text("roll_id").references(() => rolls.id),
      jobOrderId: integer("job_order_id").references(() => jobOrders.id),
      performedBy: text("performed_by").references(() => users.id),
      timestamp: timestamp("timestamp").defaultNow().notNull(),
      status: text("status").notNull().default("pending"),
      // pending, passed, failed
      notes: text("notes"),
      checklistResults: text("checklist_results").array(),
      parameterValues: text("parameter_values").array(),
      issueSeverity: text("issue_severity"),
      // minor, major, critical
      imageUrls: text("image_urls").array()
    });
    insertQualityCheckSchema = createInsertSchema(qualityChecks).omit({ id: true, timestamp: true });
    correctiveActions = pgTable("corrective_actions", {
      id: serial("id").primaryKey(),
      qualityCheckId: integer("quality_check_id").notNull().references(() => qualityChecks.id),
      assignedTo: text("assigned_to").references(() => users.id),
      description: text("description").notNull(),
      status: text("status").notNull().default("open"),
      // open, in-progress, completed, verified
      dueDate: timestamp("due_date"),
      completedDate: timestamp("completed_date"),
      verifiedBy: text("verified_by").references(() => users.id),
      notes: text("notes")
    });
    insertCorrectiveActionSchema = createInsertSchema(correctiveActions).omit({ id: true });
    smsMessages = pgTable("sms_messages", {
      id: serial("id").primaryKey(),
      recipientPhone: text("recipient_phone").notNull(),
      recipientName: text("recipient_name"),
      message: text("message").notNull(),
      status: text("status").notNull().default("pending"),
      // pending, sent, failed, delivered
      orderId: integer("order_id").references(() => orders.id),
      jobOrderId: integer("job_order_id").references(() => jobOrders.id),
      customerId: text("customer_id").references(() => customers.id),
      sentBy: text("sent_by").references(() => users.id),
      sentAt: timestamp("sent_at").defaultNow(),
      deliveredAt: timestamp("delivered_at"),
      errorMessage: text("error_message"),
      messageType: text("message_type").notNull(),
      // order_notification, status_update, custom, etc.
      twilioMessageId: text("twilio_message_id")
    });
    insertSmsMessageSchema = createInsertSchema(smsMessages).omit({
      id: true,
      sentAt: true,
      deliveredAt: true,
      twilioMessageId: true
    });
    mixMaterials = pgTable("mix_materials", {
      id: serial("id").primaryKey(),
      mixDate: timestamp("mix_date").defaultNow().notNull(),
      mixPerson: text("mix_person").notNull().references(() => users.id),
      orderId: integer("order_id").references(() => orders.id),
      totalQuantity: doublePrecision("total_quantity").default(0),
      createdAt: timestamp("created_at").defaultNow()
    });
    mixMachines = pgTable("mix_machines", {
      id: serial("id").primaryKey(),
      mixId: integer("mix_id").notNull().references(() => mixMaterials.id, { onDelete: "cascade" }),
      machineId: text("machine_id").notNull().references(() => machines.id)
    }, (table) => ({
      uniqueIndex: unique().on(table.mixId, table.machineId)
    }));
    insertMixMaterialSchema = createInsertSchema(mixMaterials).omit({
      id: true,
      mixDate: true,
      totalQuantity: true,
      createdAt: true
    });
    insertMixMachineSchema = createInsertSchema(mixMachines).omit({
      id: true
    });
    mixItems = pgTable("mix_items", {
      id: serial("id").primaryKey(),
      mixId: integer("mix_id").notNull().references(() => mixMaterials.id),
      rawMaterialId: integer("raw_material_id").notNull().references(() => rawMaterials.id),
      quantity: doublePrecision("quantity").notNull(),
      percentage: doublePrecision("percentage").default(0)
    });
    insertMixItemSchema = createInsertSchema(mixItems).omit({
      id: true,
      percentage: true
    });
  }
});

// server/db.ts
import dotenv from "dotenv";
import { Pool, neonConfig } from "@neondatabase/serverless";
import { drizzle } from "drizzle-orm/neon-serverless";
import ws from "ws";
var pool, db;
var init_db = __esm({
  "server/db.ts"() {
    "use strict";
    init_schema();
    dotenv.config();
    neonConfig.webSocketConstructor = ws;
    if (!process.env.DATABASE_URL) {
      throw new Error(
        "DATABASE_URL environment variable is missing. Please add it in the Deployments > Secrets section."
      );
    }
    pool = new Pool({ connectionString: process.env.DATABASE_URL });
    db = drizzle(pool, { schema: schema_exports });
  }
});

// server/database-storage.ts
import { eq } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";
var DatabaseStorage;
var init_database_storage = __esm({
  "server/database-storage.ts"() {
    "use strict";
    init_db();
    init_schema();
    init_db();
    DatabaseStorage = class {
      sessionStore;
      constructor() {
        const PostgresSessionStore = connectPg(session);
        this.sessionStore = new PostgresSessionStore({
          pool,
          tableName: "session",
          // Default table name is "session"
          createTableIfMissing: true
        });
      }
      // User management
      async getUsers() {
        return await db.select().from(users);
      }
      async getUser(id) {
        const result = await db.select().from(users).where(eq(users.id, id));
        return result[0];
      }
      async getUserByUsername(username) {
        const result = await db.select().from(users).where(eq(users.username, username));
        return result[0];
      }
      async createUser(user) {
        const id = `U${(await this.getUsers()).length + 1}`.padStart(4, "0");
        const newUser = { ...user, id };
        const result = await db.insert(users).values(newUser).returning();
        return result[0];
      }
      async updateUser(id, userUpdate) {
        const result = await db.update(users).set(userUpdate).where(eq(users.id, id)).returning();
        return result[0];
      }
      async deleteUser(id) {
        const result = await db.delete(users).where(eq(users.id, id)).returning();
        return result.length > 0;
      }
      // Categories
      async getCategories() {
        return await db.select().from(categories);
      }
      async getCategory(id) {
        const result = await db.select().from(categories).where(eq(categories.id, id));
        return result[0];
      }
      async getCategoryByCode(code) {
        const result = await db.select().from(categories).where(eq(categories.code, code));
        return result[0];
      }
      async createCategory(category) {
        const result = await db.insert(categories).values(category).returning();
        return result[0];
      }
      async updateCategory(id, categoryUpdate) {
        const result = await db.update(categories).set(categoryUpdate).where(eq(categories.id, id)).returning();
        return result[0];
      }
      async deleteCategory(id) {
        const result = await db.delete(categories).where(eq(categories.id, id)).returning();
        return result.length > 0;
      }
      // Items
      async getItems() {
        return await db.select().from(items);
      }
      async getItemsByCategory(categoryId) {
        return await db.select().from(items).where(eq(items.categoryId, categoryId));
      }
      async getItem(id) {
        const result = await db.select().from(items).where(eq(items.id, id));
        return result[0];
      }
      async createItem(item) {
        const result = await db.insert(items).values(item).returning();
        return result[0];
      }
      async updateItem(id, itemUpdate) {
        const result = await db.update(items).set(itemUpdate).where(eq(items.id, id)).returning();
        return result[0];
      }
      async deleteItem(id) {
        const result = await db.delete(items).where(eq(items.id, id)).returning();
        return result.length > 0;
      }
      // Sections
      async getSections() {
        return await db.select().from(sections);
      }
      async getSection(id) {
        const result = await db.select().from(sections).where(eq(sections.id, id));
        return result[0];
      }
      async createSection(section) {
        const result = await db.insert(sections).values(section).returning();
        return result[0];
      }
      async updateSection(id, sectionUpdate) {
        const result = await db.update(sections).set(sectionUpdate).where(eq(sections.id, id)).returning();
        return result[0];
      }
      async deleteSection(id) {
        const result = await db.delete(sections).where(eq(sections.id, id)).returning();
        return result.length > 0;
      }
      // Machines
      async getMachines() {
        return await db.select().from(machines);
      }
      async getMachinesBySection(sectionId) {
        return await db.select().from(machines).where(eq(machines.sectionId, sectionId));
      }
      async getMachine(id) {
        const result = await db.select().from(machines).where(eq(machines.id, id));
        return result[0];
      }
      async createMachine(machine) {
        const result = await db.insert(machines).values(machine).returning();
        return result[0];
      }
      async updateMachine(id, machineUpdate) {
        const result = await db.update(machines).set(machineUpdate).where(eq(machines.id, id)).returning();
        return result[0];
      }
      async deleteMachine(id) {
        const result = await db.delete(machines).where(eq(machines.id, id)).returning();
        return result.length > 0;
      }
      // Master Batches
      async getMasterBatches() {
        return await db.select().from(masterBatches);
      }
      async getMasterBatch(id) {
        const result = await db.select().from(masterBatches).where(eq(masterBatches.id, id));
        return result[0];
      }
      async createMasterBatch(masterBatch) {
        const result = await db.insert(masterBatches).values(masterBatch).returning();
        return result[0];
      }
      async updateMasterBatch(id, masterBatchUpdate) {
        const result = await db.update(masterBatches).set(masterBatchUpdate).where(eq(masterBatches.id, id)).returning();
        return result[0];
      }
      async deleteMasterBatch(id) {
        const result = await db.delete(masterBatches).where(eq(masterBatches.id, id)).returning();
        return result.length > 0;
      }
      // Customers
      async getCustomers() {
        return await db.select().from(customers);
      }
      async getCustomer(id) {
        const result = await db.select().from(customers).where(eq(customers.id, id));
        return result[0];
      }
      async getCustomerByCode(code) {
        const result = await db.select().from(customers).where(eq(customers.code, code));
        return result[0];
      }
      async createCustomer(customer) {
        const result = await db.insert(customers).values(customer).returning();
        return result[0];
      }
      async updateCustomer(id, customerUpdate) {
        const result = await db.update(customers).set(customerUpdate).where(eq(customers.id, id)).returning();
        return result[0];
      }
      async deleteCustomer(id) {
        const result = await db.delete(customers).where(eq(customers.id, id)).returning();
        return result.length > 0;
      }
      // Customer Products
      async getCustomerProducts() {
        return await db.select().from(customerProducts);
      }
      async getCustomerProductsByCustomer(customerId) {
        return await db.select().from(customerProducts).where(eq(customerProducts.customerId, customerId));
      }
      async getCustomerProduct(id) {
        const result = await db.select().from(customerProducts).where(eq(customerProducts.id, id));
        return result[0];
      }
      async createCustomerProduct(customerProduct) {
        const result = await db.insert(customerProducts).values(customerProduct).returning();
        return result[0];
      }
      async updateCustomerProduct(id, customerProductUpdate) {
        const result = await db.update(customerProducts).set(customerProductUpdate).where(eq(customerProducts.id, id)).returning();
        return result[0];
      }
      async deleteCustomerProduct(id) {
        const result = await db.delete(customerProducts).where(eq(customerProducts.id, id)).returning();
        return result.length > 0;
      }
      // Orders
      async getOrders() {
        return await db.select().from(orders);
      }
      async getOrder(id) {
        const result = await db.select().from(orders).where(eq(orders.id, id));
        return result[0];
      }
      async createOrder(order) {
        const result = await db.insert(orders).values(order).returning();
        return result[0];
      }
      async updateOrder(id, orderUpdate) {
        const result = await db.update(orders).set(orderUpdate).where(eq(orders.id, id)).returning();
        return result[0];
      }
      async deleteOrder(id) {
        const jobOrdersToDelete = await this.getJobOrdersByOrder(id);
        console.log(`Found ${jobOrdersToDelete.length} job orders to delete for order ${id}`);
        for (const jobOrder of jobOrdersToDelete) {
          const rollsToDelete = await this.getRollsByJobOrder(jobOrder.id);
          console.log(`Found ${rollsToDelete.length} rolls to delete for job order ${jobOrder.id}`);
          for (const roll of rollsToDelete) {
            console.log(`Deleting roll ${roll.id}`);
            await db.delete(rolls).where(eq(rolls.id, roll.id));
          }
          console.log(`Deleting job order ${jobOrder.id}`);
          await db.delete(jobOrders).where(eq(jobOrders.id, jobOrder.id));
        }
        console.log(`Deleting order ${id}`);
        const result = await db.delete(orders).where(eq(orders.id, id)).returning();
        return result.length > 0;
      }
      // Job Orders
      async getJobOrders() {
        return await db.select().from(jobOrders);
      }
      async getJobOrdersByOrder(orderId) {
        return await db.select().from(jobOrders).where(eq(jobOrders.orderId, orderId));
      }
      async getJobOrder(id) {
        const result = await db.select().from(jobOrders).where(eq(jobOrders.id, id));
        return result[0];
      }
      async createJobOrder(jobOrder) {
        const result = await db.insert(jobOrders).values(jobOrder).returning();
        return result[0];
      }
      async updateJobOrder(id, jobOrderUpdate) {
        const result = await db.update(jobOrders).set(jobOrderUpdate).where(eq(jobOrders.id, id)).returning();
        return result[0];
      }
      async deleteJobOrder(id) {
        const relatedRolls = await this.getRollsByJobOrder(id);
        console.log(`Found ${relatedRolls.length} rolls to delete for job order ${id}`);
        for (const roll of relatedRolls) {
          console.log(`Deleting roll ${roll.id}`);
          await db.delete(rolls).where(eq(rolls.id, roll.id));
        }
        console.log(`Deleting job order ${id}`);
        const result = await db.delete(jobOrders).where(eq(jobOrders.id, id)).returning();
        return result.length > 0;
      }
      // Rolls
      async getRolls() {
        return await db.select().from(rolls);
      }
      async getRollsByJobOrder(jobOrderId) {
        return await db.select().from(rolls).where(eq(rolls.jobOrderId, jobOrderId));
      }
      async getRollsByStage(stage) {
        return await db.select().from(rolls).where(eq(rolls.currentStage, stage));
      }
      async getRoll(id) {
        const result = await db.select().from(rolls).where(eq(rolls.id, id));
        return result[0];
      }
      async createRoll(roll) {
        const result = await db.insert(rolls).values(roll).returning();
        return result[0];
      }
      async updateRoll(id, rollUpdate) {
        const result = await db.update(rolls).set(rollUpdate).where(eq(rolls.id, id)).returning();
        return result[0];
      }
      async deleteRoll(id) {
        const result = await db.delete(rolls).where(eq(rolls.id, id)).returning();
        return result.length > 0;
      }
      // Raw Materials
      async getRawMaterials() {
        return await db.select().from(rawMaterials);
      }
      async getRawMaterial(id) {
        const result = await db.select().from(rawMaterials).where(eq(rawMaterials.id, id));
        return result[0];
      }
      async createRawMaterial(rawMaterial) {
        const result = await db.insert(rawMaterials).values(rawMaterial).returning();
        return result[0];
      }
      async updateRawMaterial(id, rawMaterialUpdate) {
        const result = await db.update(rawMaterials).set(rawMaterialUpdate).where(eq(rawMaterials.id, id)).returning();
        return result[0];
      }
      async deleteRawMaterial(id) {
        const result = await db.delete(rawMaterials).where(eq(rawMaterials.id, id)).returning();
        return result.length > 0;
      }
      // Final Products
      async getFinalProducts() {
        return await db.select().from(finalProducts);
      }
      async getFinalProduct(id) {
        const result = await db.select().from(finalProducts).where(eq(finalProducts.id, id));
        return result[0];
      }
      async createFinalProduct(finalProduct) {
        const result = await db.insert(finalProducts).values(finalProduct).returning();
        return result[0];
      }
      async updateFinalProduct(id, finalProductUpdate) {
        const result = await db.update(finalProducts).set(finalProductUpdate).where(eq(finalProducts.id, id)).returning();
        return result[0];
      }
      async deleteFinalProduct(id) {
        const result = await db.delete(finalProducts).where(eq(finalProducts.id, id)).returning();
        return result.length > 0;
      }
      // SMS Messages
      async getSmsMessages() {
        return await db.select().from(smsMessages);
      }
      async getSmsMessagesByOrder(orderId) {
        return await db.select().from(smsMessages).where(eq(smsMessages.orderId, orderId));
      }
      async getSmsMessagesByJobOrder(jobOrderId) {
        return await db.select().from(smsMessages).where(eq(smsMessages.jobOrderId, jobOrderId));
      }
      async getSmsMessagesByCustomer(customerId) {
        return await db.select().from(smsMessages).where(eq(smsMessages.customerId, customerId));
      }
      async getSmsMessage(id) {
        const result = await db.select().from(smsMessages).where(eq(smsMessages.id, id));
        return result[0];
      }
      async createSmsMessage(message) {
        const result = await db.insert(smsMessages).values(message).returning();
        return result[0];
      }
      async updateSmsMessage(id, messageUpdate) {
        const result = await db.update(smsMessages).set(messageUpdate).where(eq(smsMessages.id, id)).returning();
        return result[0];
      }
      async deleteSmsMessage(id) {
        const result = await db.delete(smsMessages).where(eq(smsMessages.id, id)).returning();
        return result.length > 0;
      }
      // Quality Check Types
      async getQualityCheckTypes() {
        return await db.select().from(qualityCheckTypes);
      }
      async getQualityCheckTypesByStage(stage) {
        return await db.select().from(qualityCheckTypes).where(eq(qualityCheckTypes.targetStage, stage));
      }
      async getQualityCheckType(id) {
        const result = await db.select().from(qualityCheckTypes).where(eq(qualityCheckTypes.id, id));
        return result[0];
      }
      async createQualityCheckType(qualityCheckType) {
        const result = await db.insert(qualityCheckTypes).values(qualityCheckType).returning();
        return result[0];
      }
      async updateQualityCheckType(id, qualityCheckTypeUpdate) {
        const result = await db.update(qualityCheckTypes).set(qualityCheckTypeUpdate).where(eq(qualityCheckTypes.id, id)).returning();
        return result[0];
      }
      async deleteQualityCheckType(id) {
        const result = await db.delete(qualityCheckTypes).where(eq(qualityCheckTypes.id, id)).returning();
        return result.length > 0;
      }
      // Quality Checks
      async getQualityChecks() {
        return await db.select().from(qualityChecks);
      }
      async getQualityChecksByRoll(rollId) {
        return await db.select().from(qualityChecks).where(eq(qualityChecks.rollId, rollId));
      }
      async getQualityChecksByJobOrder(jobOrderId) {
        return await db.select().from(qualityChecks).where(eq(qualityChecks.jobOrderId, jobOrderId));
      }
      async getQualityCheck(id) {
        const result = await db.select().from(qualityChecks).where(eq(qualityChecks.id, id));
        return result[0];
      }
      async createQualityCheck(qualityCheck) {
        const result = await db.insert(qualityChecks).values(qualityCheck).returning();
        return result[0];
      }
      async updateQualityCheck(id, qualityCheckUpdate) {
        const result = await db.update(qualityChecks).set(qualityCheckUpdate).where(eq(qualityChecks.id, id)).returning();
        return result[0];
      }
      async deleteQualityCheck(id) {
        const result = await db.delete(qualityChecks).where(eq(qualityChecks.id, id)).returning();
        return result.length > 0;
      }
      // Corrective Actions
      async getCorrectiveActions() {
        return await db.select().from(correctiveActions);
      }
      async getCorrectiveActionsByQualityCheck(qualityCheckId) {
        return await db.select().from(correctiveActions).where(eq(correctiveActions.qualityCheckId, qualityCheckId));
      }
      async getCorrectiveAction(id) {
        const result = await db.select().from(correctiveActions).where(eq(correctiveActions.id, id));
        return result[0];
      }
      async createCorrectiveAction(correctiveAction) {
        const result = await db.insert(correctiveActions).values(correctiveAction).returning();
        return result[0];
      }
      async updateCorrectiveAction(id, correctiveActionUpdate) {
        const result = await db.update(correctiveActions).set(correctiveActionUpdate).where(eq(correctiveActions.id, id)).returning();
        return result[0];
      }
      async deleteCorrectiveAction(id) {
        const result = await db.delete(correctiveActions).where(eq(correctiveActions.id, id)).returning();
        return result.length > 0;
      }
      // Mix Materials
      async getMixMaterials() {
        return await db.select().from(mixMaterials);
      }
      async getMixMaterial(id) {
        const result = await db.select().from(mixMaterials).where(eq(mixMaterials.id, id));
        return result[0];
      }
      async createMixMaterial(mix) {
        const result = await db.insert(mixMaterials).values({
          ...mix,
          mixDate: /* @__PURE__ */ new Date(),
          totalQuantity: 0,
          createdAt: /* @__PURE__ */ new Date()
        }).returning();
        return result[0];
      }
      async updateMixMaterial(id, mixUpdate) {
        const result = await db.update(mixMaterials).set(mixUpdate).where(eq(mixMaterials.id, id)).returning();
        return result[0];
      }
      async deleteMixMaterial(id) {
        const mixItems2 = await this.getMixItemsByMix(id);
        for (const item of mixItems2) {
          await this.deleteMixItem(item.id);
        }
        await this.deleteMixMachinesByMixId(id);
        const result = await db.delete(mixMaterials).where(eq(mixMaterials.id, id)).returning();
        return result.length > 0;
      }
      // Mix Machines
      async getMixMachines() {
        return await db.select().from(mixMachines);
      }
      async getMixMachinesByMixId(mixId) {
        return await db.select().from(mixMachines).where(eq(mixMachines.mixId, mixId));
      }
      async createMixMachine(mixMachine) {
        const result = await db.insert(mixMachines).values(mixMachine).returning();
        return result[0];
      }
      async deleteMixMachinesByMixId(mixId) {
        const result = await db.delete(mixMachines).where(eq(mixMachines.mixId, mixId)).returning();
        return result.length > 0;
      }
      // Mix Items
      async getMixItems() {
        return await db.select().from(mixItems);
      }
      async getMixItemsByMix(mixId) {
        return await db.select().from(mixItems).where(eq(mixItems.mixId, mixId));
      }
      async getMixItem(id) {
        const result = await db.select().from(mixItems).where(eq(mixItems.id, id));
        return result[0];
      }
      async createMixItem(mixItem) {
        const mix = await this.getMixMaterial(mixItem.mixId);
        if (!mix) {
          throw new Error(`Mix with ID ${mixItem.mixId} not found`);
        }
        const rawMaterial = await this.getRawMaterial(mixItem.rawMaterialId);
        if (!rawMaterial) {
          throw new Error(`Raw material with ID ${mixItem.rawMaterialId} not found`);
        }
        if (rawMaterial.quantity !== null && rawMaterial.quantity >= mixItem.quantity) {
          await this.updateRawMaterial(
            rawMaterial.id,
            { quantity: rawMaterial.quantity - mixItem.quantity }
          );
        } else {
          throw new Error(`Insufficient quantity of raw material ${rawMaterial.name}`);
        }
        const newTotalQuantity = (mix.totalQuantity || 0) + mixItem.quantity;
        await this.updateMixMaterial(mix.id, { totalQuantity: newTotalQuantity });
        const percentage = mixItem.quantity / newTotalQuantity * 100;
        const result = await db.insert(mixItems).values({
          ...mixItem,
          percentage
        }).returning();
        const existingMixItems = await this.getMixItemsByMix(mixItem.mixId);
        for (const item of existingMixItems) {
          if (item.id === result[0].id) continue;
          const updatedPercentage = item.quantity / newTotalQuantity * 100;
          await this.updateMixItem(item.id, { percentage: updatedPercentage });
        }
        return result[0];
      }
      async updateMixItem(id, mixItemUpdate) {
        const existingMixItem = await this.getMixItem(id);
        if (!existingMixItem) return void 0;
        if (mixItemUpdate.quantity !== void 0 && mixItemUpdate.quantity !== existingMixItem.quantity) {
          const mix = await this.getMixMaterial(existingMixItem.mixId);
          if (!mix) {
            throw new Error(`Mix with ID ${existingMixItem.mixId} not found`);
          }
          const quantityDiff = mixItemUpdate.quantity - existingMixItem.quantity;
          const newTotalQuantity = (mix.totalQuantity || 0) + quantityDiff;
          if (quantityDiff !== 0) {
            const rawMaterial = await this.getRawMaterial(existingMixItem.rawMaterialId);
            if (!rawMaterial) {
              throw new Error(`Raw material with ID ${existingMixItem.rawMaterialId} not found`);
            }
            if (quantityDiff > 0) {
              if (rawMaterial.quantity !== null && rawMaterial.quantity >= quantityDiff) {
                await this.updateRawMaterial(
                  rawMaterial.id,
                  { quantity: rawMaterial.quantity - quantityDiff }
                );
              } else {
                throw new Error(`Insufficient quantity of raw material ${rawMaterial.name}`);
              }
            } else {
              await this.updateRawMaterial(
                rawMaterial.id,
                { quantity: (rawMaterial.quantity || 0) - quantityDiff }
              );
            }
          }
          await this.updateMixMaterial(mix.id, { totalQuantity: newTotalQuantity });
          mixItemUpdate.percentage = mixItemUpdate.quantity / newTotalQuantity * 100;
          const mixItems2 = await this.getMixItemsByMix(existingMixItem.mixId);
          for (const item of mixItems2) {
            if (item.id === id) continue;
            const updatedPercentage = item.quantity / newTotalQuantity * 100;
            await this.updateMixItem(item.id, { percentage: updatedPercentage });
          }
        }
        const result = await db.update(mixItems).set(mixItemUpdate).where(eq(mixItems.id, id)).returning();
        return result[0];
      }
      async deleteMixItem(id) {
        const mixItem = await this.getMixItem(id);
        if (!mixItem) return false;
        const mix = await this.getMixMaterial(mixItem.mixId);
        if (!mix) {
          const result2 = await db.delete(mixItems).where(eq(mixItems.id, id)).returning();
          return result2.length > 0;
        }
        const rawMaterial = await this.getRawMaterial(mixItem.rawMaterialId);
        if (rawMaterial) {
          await this.updateRawMaterial(
            rawMaterial.id,
            { quantity: (rawMaterial.quantity || 0) + mixItem.quantity }
          );
        }
        const newTotalQuantity = (mix.totalQuantity || 0) - mixItem.quantity;
        await this.updateMixMaterial(mix.id, { totalQuantity: newTotalQuantity });
        const result = await db.delete(mixItems).where(eq(mixItems.id, id)).returning();
        if (result.length > 0) {
          const remainingItems = await this.getMixItemsByMix(mixItem.mixId);
          for (const item of remainingItems) {
            const updatedPercentage = newTotalQuantity > 0 ? item.quantity / newTotalQuantity * 100 : 0;
            await this.updateMixItem(item.id, { percentage: updatedPercentage });
          }
          return true;
        }
        return false;
      }
    };
  }
});

// server/storage.ts
import session2 from "express-session";
var storage;
var init_storage = __esm({
  "server/storage.ts"() {
    "use strict";
    init_database_storage();
    storage = new DatabaseStorage();
  }
});

// server/demo-data.ts
var demo_data_exports = {};
__export(demo_data_exports, {
  initializeDemoData: () => initializeDemoData
});
async function safeInitialize(operation, errorMessage) {
  try {
    return await operation();
  } catch (error) {
    console.warn(`${errorMessage}: ${error.message || String(error)}`);
    return null;
  }
}
async function initializeDemoData(storage2) {
  try {
    let admin = await storage2.getUserByUsername("admin");
    if (!admin) {
      admin = await storage2.createUser({
        username: "admin",
        password: "admin123",
        name: "Admin User",
        role: "administrator",
        isActive: true,
        sectionId: null
      });
    }
    let extrusionSection = await storage2.getSection("SEC001");
    if (!extrusionSection) {
      extrusionSection = await storage2.createSection({
        id: "SEC001",
        name: "Extrusion"
      });
    }
    let printingSection = await storage2.getSection("SEC002");
    if (!printingSection) {
      printingSection = await storage2.createSection({
        id: "SEC002",
        name: "Printing"
      });
    }
    let cuttingSection = await storage2.getSection("SEC003");
    if (!cuttingSection) {
      cuttingSection = await storage2.createSection({
        id: "SEC003",
        name: "Cutting"
      });
    }
    let machine1 = await storage2.getMachine("MCH001");
    if (!machine1) {
      machine1 = await storage2.createMachine({
        id: "MCH001",
        name: "Extruder 1",
        sectionId: extrusionSection.id,
        isActive: true
      });
    }
    let machine2 = await storage2.getMachine("MCH002");
    if (!machine2) {
      machine2 = await storage2.createMachine({
        id: "MCH002",
        name: "Printing Machine 1",
        sectionId: printingSection.id,
        isActive: true
      });
    }
    let machine3 = await storage2.getMachine("MCH003");
    if (!machine3) {
      machine3 = await storage2.createMachine({
        id: "MCH003",
        name: "Cutting Machine 1",
        sectionId: cuttingSection.id,
        isActive: true
      });
    }
    let whiteMb = await storage2.getMasterBatch("MB001");
    if (!whiteMb) {
      whiteMb = await storage2.createMasterBatch({
        id: "MB001",
        name: "White EP11105W"
      });
    }
    let bagCategory = await storage2.getCategory("CAT001");
    if (!bagCategory) {
      bagCategory = await storage2.createCategory({
        id: "CAT001",
        name: "Plastic Bags",
        code: "PB"
      });
    }
    let smallBag = await storage2.getItem("ITM019");
    if (!smallBag) {
      smallBag = await storage2.createItem({
        id: "ITM019",
        categoryId: bagCategory.id,
        name: "Small Plastic Bag",
        fullName: "Small HDPE Plastic Bag"
      });
    }
    let mediumBag = await storage2.getItem("ITM020");
    if (!mediumBag) {
      mediumBag = await storage2.createItem({
        id: "ITM020",
        categoryId: bagCategory.id,
        name: "Medium Plastic Bag",
        fullName: "Medium HDPE Plastic Bag"
      });
    }
    let largeBag = await storage2.getItem("ITM022");
    if (!largeBag) {
      largeBag = await storage2.createItem({
        id: "ITM022",
        categoryId: bagCategory.id,
        name: "Large Plastic Bag",
        fullName: "Large HDPE Plastic Bag"
      });
    }
    const existingRawMaterials = await storage2.getRawMaterials();
    const existingHdpe = existingRawMaterials.find((rm) => rm.name === "HDPE" && rm.type === "Plastic");
    if (!existingHdpe) {
      await storage2.createRawMaterial({
        name: "HDPE",
        type: "Plastic",
        quantity: 1e3,
        unit: "Kg"
      });
    }
    const existingLdpe = existingRawMaterials.find((rm) => rm.name === "LDPE" && rm.type === "Plastic");
    if (!existingLdpe) {
      await storage2.createRawMaterial({
        name: "LDPE",
        type: "Plastic",
        quantity: 750,
        unit: "Kg"
      });
    }
    let customer1 = await safeInitialize(
      async () => {
        const existingCustomer = await storage2.getCustomer("CUST001");
        if (existingCustomer) return existingCustomer;
        return await storage2.createCustomer({
          id: "CUST001",
          code: "PH001",
          name: "Price House",
          nameAr: "",
          userId: admin.id,
          plateDrawerCode: "A-01"
        });
      },
      "Failed to get or create customer 1"
    );
    if (!customer1) {
      customer1 = {
        id: "CUST001",
        code: "PH001",
        name: "Price House"
      };
    }
    let customer2 = await safeInitialize(
      async () => {
        const existingCustomer = await storage2.getCustomer("CUST002");
        if (existingCustomer) return existingCustomer;
        return await storage2.createCustomer({
          id: "CUST002",
          code: "SM002",
          name: "Supermarket Chain",
          nameAr: "",
          userId: admin.id,
          plateDrawerCode: "B-02"
        });
      },
      "Failed to get or create customer 2"
    );
    if (!customer2) {
      customer2 = {
        id: "CUST002",
        code: "SM002",
        name: "Supermarket Chain"
      };
    }
    const existingProducts = await storage2.getCustomerProducts();
    let product1 = existingProducts.find((p) => p.customerId === customer1.id && p.itemId === smallBag.id);
    if (!product1) {
      product1 = await storage2.createCustomerProduct({
        customerId: customer1.id,
        categoryId: bagCategory.id,
        itemId: smallBag.id,
        sizeCaption: "9\xD79+28",
        width: 9,
        leftF: 9,
        rightF: 28,
        thickness: 15,
        thicknessOne: 15,
        printingCylinder: 0,
        lengthCm: 0,
        cuttingLength: 0,
        rawMaterial: "HDPE",
        masterBatchId: whiteMb.id,
        printed: "/",
        cuttingUnit: "Kg",
        unitWeight: 1,
        packing: "20K/Bag",
        punching: "None",
        cover: "-",
        volum: null,
        knife: null,
        notes: null
      });
    }
    let product2 = existingProducts.find((p) => p.customerId === customer1.id && p.itemId === mediumBag.id);
    if (!product2) {
      product2 = await storage2.createCustomerProduct({
        customerId: customer1.id,
        categoryId: bagCategory.id,
        itemId: mediumBag.id,
        sizeCaption: "10\xD710+35",
        width: 10,
        leftF: 10,
        rightF: 35,
        thickness: 12,
        thicknessOne: 12,
        printingCylinder: 0,
        lengthCm: 0,
        cuttingLength: 0,
        rawMaterial: "HDPE",
        masterBatchId: whiteMb.id,
        printed: "/",
        cuttingUnit: "Kg",
        unitWeight: 1.2,
        packing: "20K/Bag",
        punching: "None",
        cover: "-",
        volum: null,
        knife: null,
        notes: null
      });
    }
    let product3 = existingProducts.find((p) => p.customerId === customer2.id && p.itemId === largeBag.id);
    if (!product3) {
      product3 = await storage2.createCustomerProduct({
        customerId: customer2.id,
        categoryId: bagCategory.id,
        itemId: largeBag.id,
        sizeCaption: "12\xD712+45",
        width: 12,
        leftF: 12,
        rightF: 45,
        thickness: 10,
        thicknessOne: 10,
        printingCylinder: 0,
        lengthCm: 0,
        cuttingLength: 0,
        rawMaterial: "LDPE",
        masterBatchId: whiteMb.id,
        printed: "/",
        cuttingUnit: "Kg",
        unitWeight: 1.5,
        packing: "20K/Bag",
        punching: "None",
        cover: "-",
        volum: null,
        knife: null,
        notes: null
      });
    }
    const existingOrders = await storage2.getOrders();
    let order1;
    let order1Id = -1;
    const existingOrder1 = existingOrders.find((o) => o.customerId === customer1.id && o.note === "Urgent delivery needed");
    if (existingOrder1) {
      order1 = existingOrder1;
      order1Id = existingOrder1.id;
    } else {
      order1 = await storage2.createOrder({
        customerId: customer1.id,
        note: "Urgent delivery needed",
        userId: admin.id
      });
      order1Id = order1.id;
      await storage2.updateOrder(order1.id, {
        status: "processing"
      });
    }
    const existingJobOrders = await storage2.getJobOrders();
    let jobOrder1;
    const existingJobOrder1 = existingJobOrders.find((jo) => jo.orderId === order1Id && jo.customerProductId === product1.id);
    if (!existingJobOrder1) {
      jobOrder1 = await storage2.createJobOrder({
        orderId: order1Id,
        customerProductId: product1.id,
        quantity: 500
      });
    } else {
      jobOrder1 = existingJobOrder1;
    }
    let jobOrder2;
    const existingJobOrder2 = existingJobOrders.find((jo) => jo.orderId === order1Id && jo.customerProductId === product2.id);
    if (!existingJobOrder2) {
      jobOrder2 = await storage2.createJobOrder({
        orderId: order1Id,
        customerProductId: product2.id,
        quantity: 600
      });
    } else {
      jobOrder2 = existingJobOrder2;
    }
    let order2;
    let order2Id = -1;
    const existingOrder2 = existingOrders.find((o) => o.customerId === customer2.id && o.note === "Monthly repeated order");
    if (existingOrder2) {
      order2 = existingOrder2;
      order2Id = existingOrder2.id;
    } else {
      order2 = await storage2.createOrder({
        customerId: customer2.id,
        note: "Monthly repeated order",
        userId: admin.id
      });
      order2Id = order2.id;
      await storage2.updateOrder(order2.id, {
        status: "pending"
      });
    }
    let jobOrder3;
    const existingJobOrder3 = existingJobOrders.find((jo) => jo.orderId === order2Id && jo.customerProductId === product3.id);
    if (!existingJobOrder3) {
      jobOrder3 = await storage2.createJobOrder({
        orderId: order2Id,
        customerProductId: product3.id,
        quantity: 400
      });
    } else {
      jobOrder3 = existingJobOrder3;
    }
    const existingRolls = await storage2.getRolls();
    let roll1 = existingRolls.find((r) => r.id === "EX-124");
    if (!roll1 && jobOrder1) {
      roll1 = await storage2.createRoll({
        id: "EX-124",
        jobOrderId: jobOrder1.id,
        serialNumber: "124",
        extrudingQty: 100,
        printingQty: 0,
        cuttingQty: 0,
        currentStage: "extrusion",
        status: "processing"
      });
    }
    let roll2 = existingRolls.find((r) => r.id === "EX-125");
    if (!roll2 && jobOrder2) {
      roll2 = await storage2.createRoll({
        id: "EX-125",
        jobOrderId: jobOrder2.id,
        serialNumber: "125",
        extrudingQty: 75,
        printingQty: 0,
        cuttingQty: 0,
        currentStage: "extrusion",
        status: "pending"
      });
    }
    let roll3 = existingRolls.find((r) => r.id === "PR-089");
    if (!roll3 && jobOrder3) {
      roll3 = await storage2.createRoll({
        id: "PR-089",
        jobOrderId: jobOrder3.id,
        serialNumber: "089",
        extrudingQty: 100,
        printingQty: 75,
        cuttingQty: 0,
        currentStage: "printing",
        status: "processing"
      });
    }
    const existingInk = existingRawMaterials.find((rm) => rm.name === "Colored Ink" && rm.type === "Ink");
    if (!existingInk) {
      await storage2.createRawMaterial({
        name: "Colored Ink",
        type: "Ink",
        quantity: 500,
        unit: "L"
      });
    }
    if (existingHdpe) {
      await storage2.updateRawMaterial(existingHdpe.id, {
        quantity: 2400
        // Update to a higher quantity to simulate a purchase
      });
    }
    return { success: true };
  } catch (error) {
    console.error("Failed to initialize demo data:", error);
    return { success: false, error };
  }
}
var init_demo_data = __esm({
  "server/demo-data.ts"() {
    "use strict";
  }
});

// server/import-utils.ts
var import_utils_exports = {};
__export(import_utils_exports, {
  importFromCSV: () => importFromCSV
});
import { parse } from "csv-parse/sync";
async function importFromCSV(entityType, csvData, storage2) {
  const records = parse(csvData, {
    columns: true,
    skip_empty_lines: true,
    trim: true
  });
  if (records.length === 0) {
    return { success: false, message: "No records found in the CSV file" };
  }
  const results = {
    success: true,
    created: 0,
    updated: 0,
    failed: 0,
    errors: []
  };
  try {
    switch (entityType) {
      case "categories":
        await importCategories(records, storage2, results);
        break;
      case "customers":
        await importCustomers(records, storage2, results);
        break;
      case "items":
        await importItems(records, storage2, results);
        break;
      case "customerProducts":
        await importCustomerProducts(records, storage2, results);
        break;
      case "sections":
        await importSections(records, storage2, results);
        break;
      case "machines":
        await importMachines(records, storage2, results);
        break;
      case "masterBatches":
        await importMasterBatches(records, storage2, results);
        break;
      case "rawMaterials":
        await importRawMaterials(records, storage2, results);
        break;
      case "users":
        await importUsers(records, storage2, results);
        break;
      default:
        return { success: false, message: `Unsupported entity type: ${entityType}` };
    }
    return results;
  } catch (error) {
    return {
      success: false,
      message: `Error processing ${entityType}: ${error.message}`,
      errors: results.errors
    };
  }
}
async function safeProcess(record, process2, results) {
  try {
    return await process2();
  } catch (error) {
    results.failed++;
    results.errors.push(`Error processing record ${JSON.stringify(record)}: ${error.message}`);
    return null;
  }
}
async function importCategories(records, storage2, results) {
  for (const record of records) {
    const existingCategory = await storage2.getCategory(record.id);
    if (existingCategory) {
      await safeProcess(record, async () => {
        const updated = await storage2.updateCategory(record.id, {
          name: record.name,
          code: record.code
        });
        if (updated) results.updated++;
        return updated;
      }, results);
    } else {
      await safeProcess(record, async () => {
        const created = await storage2.createCategory({
          id: record.id,
          name: record.name,
          code: record.code
        });
        results.created++;
        return created;
      }, results);
    }
  }
}
async function importCustomers(records, storage2, results) {
  for (const record of records) {
    const existingCustomer = await storage2.getCustomer(record.id);
    if (existingCustomer) {
      await safeProcess(record, async () => {
        const updated = await storage2.updateCustomer(record.id, {
          code: record.code,
          name: record.name,
          nameAr: record.nameAr || "",
          userId: record.userId || null,
          plateDrawerCode: record.plateDrawerCode || null
        });
        if (updated) results.updated++;
        return updated;
      }, results);
    } else {
      await safeProcess(record, async () => {
        const created = await storage2.createCustomer({
          id: record.id,
          code: record.code,
          name: record.name,
          nameAr: record.nameAr || "",
          userId: record.userId || null,
          plateDrawerCode: record.plateDrawerCode || null
        });
        results.created++;
        return created;
      }, results);
    }
  }
}
async function importItems(records, storage2, results) {
  for (const record of records) {
    const existingItem = await storage2.getItem(record.id);
    if (existingItem) {
      await safeProcess(record, async () => {
        const updated = await storage2.updateItem(record.id, {
          categoryId: record.categoryId,
          name: record.name,
          fullName: record.fullName
        });
        if (updated) results.updated++;
        return updated;
      }, results);
    } else {
      await safeProcess(record, async () => {
        const created = await storage2.createItem({
          id: record.id,
          categoryId: record.categoryId,
          name: record.name,
          fullName: record.fullName
        });
        results.created++;
        return created;
      }, results);
    }
  }
}
async function importCustomerProducts(records, storage2, results) {
  for (const record of records) {
    const existingProducts = await storage2.getCustomerProducts();
    const existingProduct = existingProducts.find(
      (p) => p.customerId === record.customerId && p.itemId === record.itemId
    );
    if (existingProduct) {
      await safeProcess(record, async () => {
        const updated = await storage2.updateCustomerProduct(existingProduct.id, {
          customerId: record.customerId,
          categoryId: record.categoryId,
          itemId: record.itemId,
          sizeCaption: record.sizeCaption,
          width: parseFloat(record.width),
          leftF: parseFloat(record.leftF),
          rightF: parseFloat(record.rightF),
          thickness: parseFloat(record.thickness),
          thicknessOne: parseFloat(record.thicknessOne),
          printingCylinder: parseFloat(record.printingCylinder) || 0,
          lengthCm: parseFloat(record.lengthCm) || 0,
          cuttingLength: parseFloat(record.cuttingLength) || 0,
          rawMaterial: record.rawMaterial,
          masterBatchId: record.masterBatchId,
          printed: record.printed,
          cuttingUnit: record.cuttingUnit,
          unitWeight: parseFloat(record.unitWeight),
          packing: record.packing,
          punching: record.punching,
          cover: record.cover,
          volum: record.volum || null,
          knife: record.knife || null,
          notes: record.notes || null
        });
        if (updated) results.updated++;
        return updated;
      }, results);
    } else {
      await safeProcess(record, async () => {
        const created = await storage2.createCustomerProduct({
          customerId: record.customerId,
          categoryId: record.categoryId,
          itemId: record.itemId,
          sizeCaption: record.sizeCaption,
          width: parseFloat(record.width),
          leftF: parseFloat(record.leftF),
          rightF: parseFloat(record.rightF),
          thickness: parseFloat(record.thickness),
          thicknessOne: parseFloat(record.thicknessOne),
          printingCylinder: parseFloat(record.printingCylinder) || 0,
          lengthCm: parseFloat(record.lengthCm) || 0,
          cuttingLength: parseFloat(record.cuttingLength) || 0,
          rawMaterial: record.rawMaterial,
          masterBatchId: record.masterBatchId,
          printed: record.printed,
          cuttingUnit: record.cuttingUnit,
          unitWeight: parseFloat(record.unitWeight),
          packing: record.packing,
          punching: record.punching,
          cover: record.cover,
          volum: record.volum || null,
          knife: record.knife || null,
          notes: record.notes || null
        });
        results.created++;
        return created;
      }, results);
    }
  }
}
async function importSections(records, storage2, results) {
  for (const record of records) {
    const existingSection = await storage2.getSection(record.id);
    if (existingSection) {
      await safeProcess(record, async () => {
        const updated = await storage2.updateSection(record.id, {
          name: record.name
        });
        if (updated) results.updated++;
        return updated;
      }, results);
    } else {
      await safeProcess(record, async () => {
        const created = await storage2.createSection({
          id: record.id,
          name: record.name
        });
        results.created++;
        return created;
      }, results);
    }
  }
}
async function importMachines(records, storage2, results) {
  for (const record of records) {
    const existingMachine = await storage2.getMachine(record.id);
    if (existingMachine) {
      await safeProcess(record, async () => {
        const updated = await storage2.updateMachine(record.id, {
          name: record.name,
          sectionId: record.sectionId,
          isActive: record.isActive === "true"
        });
        if (updated) results.updated++;
        return updated;
      }, results);
    } else {
      await safeProcess(record, async () => {
        const created = await storage2.createMachine({
          id: record.id,
          name: record.name,
          sectionId: record.sectionId,
          isActive: record.isActive === "true"
        });
        results.created++;
        return created;
      }, results);
    }
  }
}
async function importMasterBatches(records, storage2, results) {
  for (const record of records) {
    const existingMasterBatch = await storage2.getMasterBatch(record.id);
    if (existingMasterBatch) {
      await safeProcess(record, async () => {
        const updated = await storage2.updateMasterBatch(record.id, {
          name: record.name
        });
        if (updated) results.updated++;
        return updated;
      }, results);
    } else {
      await safeProcess(record, async () => {
        const created = await storage2.createMasterBatch({
          id: record.id,
          name: record.name
        });
        results.created++;
        return created;
      }, results);
    }
  }
}
async function importRawMaterials(records, storage2, results) {
  const existingRawMaterials = await storage2.getRawMaterials();
  for (const record of records) {
    const existingMaterial = existingRawMaterials.find(
      (m) => m.name === record.name && m.type === record.type
    );
    if (existingMaterial) {
      await safeProcess(record, async () => {
        const updated = await storage2.updateRawMaterial(existingMaterial.id, {
          name: record.name,
          type: record.type,
          quantity: parseFloat(record.quantity),
          unit: record.unit
        });
        if (updated) results.updated++;
        return updated;
      }, results);
    } else {
      await safeProcess(record, async () => {
        const created = await storage2.createRawMaterial({
          name: record.name,
          type: record.type,
          quantity: parseFloat(record.quantity),
          unit: record.unit
        });
        results.created++;
        return created;
      }, results);
    }
  }
}
async function importUsers(records, storage2, results) {
  for (const record of records) {
    const existingUser = await storage2.getUserByUsername(record.username);
    if (existingUser) {
      await safeProcess(record, async () => {
        const updated = await storage2.updateUser(existingUser.id, {
          username: record.username,
          // Only update password if it's provided and not empty
          ...record.password ? { password: record.password } : {},
          name: record.name,
          role: record.role,
          isActive: record.isActive === "true",
          sectionId: record.sectionId || null
        });
        if (updated) results.updated++;
        return updated;
      }, results);
    } else {
      await safeProcess(record, async () => {
        const created = await storage2.createUser({
          username: record.username,
          password: record.password,
          name: record.name,
          role: record.role,
          isActive: record.isActive === "true",
          sectionId: record.sectionId || null
        });
        results.created++;
        return created;
      }, results);
    }
  }
}
var init_import_utils = __esm({
  "server/import-utils.ts"() {
    "use strict";
  }
});

// server/services/sms-service.ts
var sms_service_exports = {};
__export(sms_service_exports, {
  SmsService: () => SmsService
});
import twilio from "twilio";
var Twilio, accountSid, authToken, twilioPhoneNumber, SmsService;
var init_sms_service = __esm({
  "server/services/sms-service.ts"() {
    "use strict";
    init_storage();
    Twilio = twilio;
    accountSid = process.env.TWILIO_ACCOUNT_SID;
    authToken = process.env.TWILIO_AUTH_TOKEN;
    twilioPhoneNumber = process.env.TWILIO_PHONE_NUMBER;
    SmsService = class {
      static twilioClient = null;
      // Initialize the Twilio client if credentials are available
      static getTwilioClient() {
        if (this.twilioClient) {
          return this.twilioClient;
        }
        if (!accountSid || !authToken || !twilioPhoneNumber) {
          console.error("Twilio credentials not found in environment variables.");
          return null;
        }
        try {
          this.twilioClient = new Twilio(accountSid, authToken);
          return this.twilioClient;
        } catch (error) {
          console.error("Failed to initialize Twilio client:", error);
          return null;
        }
      }
      // Send a message and record it in the database
      static async sendMessage(messageData) {
        const message = await storage.createSmsMessage({
          ...messageData,
          status: "pending",
          sentAt: /* @__PURE__ */ new Date(),
          deliveredAt: null,
          twilioMessageId: null
        });
        try {
          const client = this.getTwilioClient();
          if (!client) {
            return await storage.updateSmsMessage(message.id, {
              status: "failed",
              errorMessage: "Twilio client not initialized. Check environment credentials."
            });
          }
          const twilioMessage = await client.messages.create({
            body: messageData.message,
            from: twilioPhoneNumber,
            to: messageData.recipientPhone
          });
          return await storage.updateSmsMessage(message.id, {
            status: "sent",
            twilioMessageId: twilioMessage.sid
          });
        } catch (error) {
          console.error("Failed to send SMS:", error);
          return await storage.updateSmsMessage(message.id, {
            status: "failed",
            errorMessage: error.message || "Failed to send SMS"
          });
        }
      }
      // Send order notification
      static async sendOrderNotification(orderId, recipientPhone, message, sentBy, recipientName, customerId) {
        return this.sendMessage({
          recipientPhone,
          message,
          messageType: "order_notification",
          orderId,
          customerId,
          recipientName,
          sentBy,
          jobOrderId: null
        });
      }
      // Send job order status update
      static async sendJobOrderUpdate(jobOrderId, recipientPhone, message, sentBy, recipientName, customerId) {
        return this.sendMessage({
          recipientPhone,
          message,
          messageType: "status_update",
          jobOrderId,
          customerId,
          recipientName,
          sentBy,
          orderId: null
        });
      }
      // Send custom message
      static async sendCustomMessage(recipientPhone, message, sentBy, recipientName, customerId, orderId, jobOrderId) {
        return this.sendMessage({
          recipientPhone,
          message,
          messageType: "custom",
          customerId,
          recipientName,
          sentBy,
          orderId,
          jobOrderId
        });
      }
      // Check message status and update in the database
      static async checkMessageStatus(messageId) {
        const message = await storage.getSmsMessage(messageId);
        if (!message || !message.twilioMessageId) {
          return message;
        }
        const client = this.getTwilioClient();
        if (!client) {
          return message;
        }
        try {
          const twilioMessage = await client.messages(message.twilioMessageId).fetch();
          const status = twilioMessage.status.toLowerCase();
          if (status !== message.status) {
            const updatedMessage = await storage.updateSmsMessage(messageId, {
              status,
              deliveredAt: status === "delivered" ? /* @__PURE__ */ new Date() : message.deliveredAt
            });
            return updatedMessage;
          }
          return message;
        } catch (error) {
          console.error(`Failed to check status for message ${messageId}:`, error);
          return message;
        }
      }
    };
  }
});

// server/index.ts
import dotenv2 from "dotenv";
import express2 from "express";
import fileUpload from "express-fileupload";

// server/routes.ts
init_storage();
init_schema();
import { createServer } from "http";
import { z } from "zod";

// server/auth.ts
init_storage();
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import session3 from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
var scryptAsync = promisify(scrypt);
async function hashPassword(password) {
  const salt = randomBytes(16).toString("hex");
  const buf = await scryptAsync(password, salt, 64);
  return `${buf.toString("hex")}.${salt}`;
}
async function comparePasswords(supplied, stored) {
  if (!stored || !stored.includes(".")) {
    return supplied === stored;
  }
  const [hashed, salt] = stored.split(".");
  if (!hashed || !salt) {
    return false;
  }
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = await scryptAsync(supplied, salt, 64);
  return timingSafeEqual(hashedBuf, suppliedBuf);
}
function setupAuth(app2) {
  const sessionSettings = {
    secret: process.env.SESSION_SECRET || "supersecretkey",
    // In production, use env var
    resave: false,
    saveUninitialized: false,
    store: storage.sessionStore,
    cookie: {
      maxAge: 24 * 60 * 60 * 1e3,
      // 1 day
      httpOnly: true,
      secure: process.env.NODE_ENV === "production"
      // Use secure cookies in production
    }
  };
  app2.set("trust proxy", 1);
  app2.use(session3(sessionSettings));
  app2.use(passport.initialize());
  app2.use(passport.session());
  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        const user = await storage.getUserByUsername(username);
        if (!user || !await comparePasswords(password, user.password)) {
          return done(null, false, { message: "Invalid username or password" });
        }
        const { password: _, ...userWithoutPassword } = user;
        return done(null, userWithoutPassword);
      } catch (error) {
        return done(error);
      }
    })
  );
  passport.serializeUser((user, done) => {
    done(null, user.id);
  });
  passport.deserializeUser(async (id, done) => {
    try {
      const user = await storage.getUser(id);
      if (!user) {
        return done(null, false);
      }
      const { password: _, ...userWithoutPassword } = user;
      done(null, userWithoutPassword);
    } catch (error) {
      done(error);
    }
  });
  app2.post("/api/register", async (req, res, next) => {
    try {
      const existingUser = await storage.getUserByUsername(req.body.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }
      const hashedPassword = await hashPassword(req.body.password);
      const user = await storage.createUser({
        ...req.body,
        password: hashedPassword
      });
      req.login(user, (err) => {
        if (err) return next(err);
        const { password: _, ...userWithoutPassword } = user;
        res.status(201).json(userWithoutPassword);
      });
    } catch (error) {
      next(error);
    }
  });
  app2.post("/api/login", (req, res, next) => {
    passport.authenticate("local", (err, user, info) => {
      if (err) return next(err);
      if (!user) {
        return res.status(401).json({ message: info?.message || "Authentication failed" });
      }
      req.login(user, (err2) => {
        if (err2) return next(err2);
        return res.json(user);
      });
    })(req, res, next);
  });
  app2.post("/api/logout", (req, res) => {
    req.logout((err) => {
      if (err) {
        return res.status(500).json({ message: "Failed to logout" });
      }
      res.status(200).json({ message: "Logged out successfully" });
    });
  });
  app2.get("/api/user", (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    res.json(req.user);
  });
}

// server/routes.ts
async function registerRoutes(app2) {
  setupAuth(app2);
  const apiRouter = app2.route("/api");
  const requireAuth = (req, res, next) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Authentication required" });
    }
    next();
  };
  app2.get("/api/categories", async (_req, res) => {
    try {
      const categories2 = await storage.getCategories();
      res.json(categories2);
    } catch (error) {
      res.status(500).json({ message: "Failed to get categories" });
    }
  });
  app2.get("/api/categories/:id", async (req, res) => {
    try {
      const category = await storage.getCategory(req.params.id);
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      res.json(category);
    } catch (error) {
      res.status(500).json({ message: "Failed to get category" });
    }
  });
  app2.post("/api/categories", async (req, res) => {
    try {
      const validatedData = insertCategorySchema.parse(req.body);
      const existingCategory = await storage.getCategoryByCode(validatedData.code);
      if (existingCategory) {
        return res.status(409).json({ message: "Category code already exists" });
      }
      const category = await storage.createCategory(validatedData);
      res.status(201).json(category);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid category data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create category" });
    }
  });
  app2.put("/api/categories/:id", async (req, res) => {
    try {
      const existingCategory = await storage.getCategory(req.params.id);
      if (!existingCategory) {
        return res.status(404).json({ message: "Category not found" });
      }
      const validatedData = insertCategorySchema.parse(req.body);
      if (validatedData.code !== existingCategory.code) {
        const existingWithCode = await storage.getCategoryByCode(validatedData.code);
        if (existingWithCode && existingWithCode.id !== req.params.id) {
          return res.status(409).json({ message: "Category code already exists" });
        }
      }
      const category = await storage.updateCategory(req.params.id, validatedData);
      res.json(category);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid category data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update category" });
    }
  });
  app2.delete("/api/categories/:id", async (req, res) => {
    try {
      const category = await storage.getCategory(req.params.id);
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      const items2 = await storage.getItemsByCategory(req.params.id);
      if (items2.length > 0) {
        return res.status(409).json({ message: "Cannot delete category with associated items" });
      }
      await storage.deleteCategory(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete category" });
    }
  });
  app2.get("/api/items", async (_req, res) => {
    try {
      const items2 = await storage.getItems();
      res.json(items2);
    } catch (error) {
      res.status(500).json({ message: "Failed to get items" });
    }
  });
  app2.get("/api/categories/:categoryId/items", async (req, res) => {
    try {
      const category = await storage.getCategory(req.params.categoryId);
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      const items2 = await storage.getItemsByCategory(req.params.categoryId);
      res.json(items2);
    } catch (error) {
      res.status(500).json({ message: "Failed to get items" });
    }
  });
  app2.get("/api/items/:id", async (req, res) => {
    try {
      const item = await storage.getItem(req.params.id);
      if (!item) {
        return res.status(404).json({ message: "Item not found" });
      }
      res.json(item);
    } catch (error) {
      res.status(500).json({ message: "Failed to get item" });
    }
  });
  app2.post("/api/items", async (req, res) => {
    try {
      const validatedData = insertItemSchema.parse(req.body);
      const category = await storage.getCategory(validatedData.categoryId);
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      const item = await storage.createItem(validatedData);
      res.status(201).json(item);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid item data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create item" });
    }
  });
  app2.put("/api/items/:id", async (req, res) => {
    try {
      const existingItem = await storage.getItem(req.params.id);
      if (!existingItem) {
        return res.status(404).json({ message: "Item not found" });
      }
      const validatedData = insertItemSchema.parse(req.body);
      const category = await storage.getCategory(validatedData.categoryId);
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      const item = await storage.updateItem(req.params.id, validatedData);
      res.json(item);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid item data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update item" });
    }
  });
  app2.delete("/api/items/:id", async (req, res) => {
    try {
      const item = await storage.getItem(req.params.id);
      if (!item) {
        return res.status(404).json({ message: "Item not found" });
      }
      await storage.deleteItem(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete item" });
    }
  });
  app2.get("/api/sections", async (_req, res) => {
    try {
      const sections2 = await storage.getSections();
      res.json(sections2);
    } catch (error) {
      res.status(500).json({ message: "Failed to get sections" });
    }
  });
  app2.get("/api/sections/:id", async (req, res) => {
    try {
      const section = await storage.getSection(req.params.id);
      if (!section) {
        return res.status(404).json({ message: "Section not found" });
      }
      res.json(section);
    } catch (error) {
      res.status(500).json({ message: "Failed to get section" });
    }
  });
  app2.post("/api/sections", async (req, res) => {
    try {
      const validatedData = insertSectionSchema.parse(req.body);
      const section = await storage.createSection(validatedData);
      res.status(201).json(section);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid section data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create section" });
    }
  });
  app2.put("/api/sections/:id", async (req, res) => {
    try {
      const existingSection = await storage.getSection(req.params.id);
      if (!existingSection) {
        return res.status(404).json({ message: "Section not found" });
      }
      const validatedData = insertSectionSchema.parse(req.body);
      const section = await storage.updateSection(req.params.id, validatedData);
      res.json(section);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid section data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update section" });
    }
  });
  app2.delete("/api/sections/:id", async (req, res) => {
    try {
      const section = await storage.getSection(req.params.id);
      if (!section) {
        return res.status(404).json({ message: "Section not found" });
      }
      await storage.deleteSection(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete section" });
    }
  });
  app2.get("/api/machines", async (_req, res) => {
    try {
      const machines2 = await storage.getMachines();
      res.json(machines2);
    } catch (error) {
      res.status(500).json({ message: "Failed to get machines" });
    }
  });
  app2.get("/api/sections/:sectionId/machines", async (req, res) => {
    try {
      const section = await storage.getSection(req.params.sectionId);
      if (!section) {
        return res.status(404).json({ message: "Section not found" });
      }
      const machines2 = await storage.getMachinesBySection(req.params.sectionId);
      res.json(machines2);
    } catch (error) {
      res.status(500).json({ message: "Failed to get machines" });
    }
  });
  app2.get("/api/machines/:id", async (req, res) => {
    try {
      const machine = await storage.getMachine(req.params.id);
      if (!machine) {
        return res.status(404).json({ message: "Machine not found" });
      }
      res.json(machine);
    } catch (error) {
      res.status(500).json({ message: "Failed to get machine" });
    }
  });
  app2.post("/api/machines", async (req, res) => {
    try {
      const validatedData = insertMachineSchema.parse(req.body);
      if (validatedData.sectionId) {
        const section = await storage.getSection(validatedData.sectionId);
        if (!section) {
          return res.status(404).json({ message: "Section not found" });
        }
      }
      const machine = await storage.createMachine(validatedData);
      res.status(201).json(machine);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid machine data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create machine" });
    }
  });
  app2.put("/api/machines/:id", async (req, res) => {
    try {
      const existingMachine = await storage.getMachine(req.params.id);
      if (!existingMachine) {
        return res.status(404).json({ message: "Machine not found" });
      }
      const validatedData = insertMachineSchema.parse(req.body);
      if (validatedData.sectionId) {
        const section = await storage.getSection(validatedData.sectionId);
        if (!section) {
          return res.status(404).json({ message: "Section not found" });
        }
      }
      const machine = await storage.updateMachine(req.params.id, validatedData);
      res.json(machine);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid machine data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update machine" });
    }
  });
  app2.delete("/api/machines/:id", async (req, res) => {
    try {
      const machine = await storage.getMachine(req.params.id);
      if (!machine) {
        return res.status(404).json({ message: "Machine not found" });
      }
      await storage.deleteMachine(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete machine" });
    }
  });
  app2.get("/api/master-batches", async (_req, res) => {
    try {
      const masterBatches2 = await storage.getMasterBatches();
      res.json(masterBatches2);
    } catch (error) {
      res.status(500).json({ message: "Failed to get master batches" });
    }
  });
  app2.get("/api/master-batches/:id", async (req, res) => {
    try {
      const masterBatch = await storage.getMasterBatch(req.params.id);
      if (!masterBatch) {
        return res.status(404).json({ message: "Master batch not found" });
      }
      res.json(masterBatch);
    } catch (error) {
      res.status(500).json({ message: "Failed to get master batch" });
    }
  });
  app2.post("/api/master-batches", async (req, res) => {
    try {
      const validatedData = insertMasterBatchSchema.parse(req.body);
      const masterBatch = await storage.createMasterBatch(validatedData);
      res.status(201).json(masterBatch);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid master batch data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create master batch" });
    }
  });
  app2.put("/api/master-batches/:id", async (req, res) => {
    try {
      const existingMasterBatch = await storage.getMasterBatch(req.params.id);
      if (!existingMasterBatch) {
        return res.status(404).json({ message: "Master batch not found" });
      }
      const validatedData = insertMasterBatchSchema.parse(req.body);
      const masterBatch = await storage.updateMasterBatch(req.params.id, validatedData);
      res.json(masterBatch);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid master batch data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update master batch" });
    }
  });
  app2.delete("/api/master-batches/:id", async (req, res) => {
    try {
      const masterBatch = await storage.getMasterBatch(req.params.id);
      if (!masterBatch) {
        return res.status(404).json({ message: "Master batch not found" });
      }
      await storage.deleteMasterBatch(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete master batch" });
    }
  });
  app2.get("/api/users", async (_req, res) => {
    try {
      const users2 = await storage.getUsers();
      const sanitizedUsers = users2.map(({ password, ...rest }) => rest);
      res.json(sanitizedUsers);
    } catch (error) {
      res.status(500).json({ message: "Failed to get users" });
    }
  });
  app2.get("/api/users/:id", async (req, res) => {
    try {
      const user = await storage.getUser(req.params.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ message: "Failed to get user" });
    }
  });
  app2.post("/api/users", async (req, res) => {
    try {
      const validatedData = insertUserSchema.parse(req.body);
      const existingUser = await storage.getUserByUsername(validatedData.username);
      if (existingUser) {
        return res.status(409).json({ message: "Username already exists" });
      }
      if (validatedData.sectionId) {
        const section = await storage.getSection(validatedData.sectionId);
        if (!section) {
          return res.status(404).json({ message: "Section not found" });
        }
      }
      const user = await storage.createUser(validatedData);
      const { password, ...userWithoutPassword } = user;
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid user data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create user" });
    }
  });
  app2.put("/api/users/:id", async (req, res) => {
    try {
      const existingUser = await storage.getUser(req.params.id);
      if (!existingUser) {
        return res.status(404).json({ message: "User not found" });
      }
      const validatedData = insertUserSchema.parse(req.body);
      if (validatedData.username !== existingUser.username) {
        const usernameExists = await storage.getUserByUsername(validatedData.username);
        if (usernameExists) {
          return res.status(409).json({ message: "Username already exists" });
        }
      }
      if (validatedData.sectionId) {
        const section = await storage.getSection(validatedData.sectionId);
        if (!section) {
          return res.status(404).json({ message: "Section not found" });
        }
      }
      const user = await storage.updateUser(req.params.id, validatedData);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid user data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update user" });
    }
  });
  app2.delete("/api/users/:id", async (req, res) => {
    try {
      const user = await storage.getUser(req.params.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      await storage.deleteUser(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete user" });
    }
  });
  app2.get("/api/customers", async (_req, res) => {
    try {
      const customers2 = await storage.getCustomers();
      res.json(customers2);
    } catch (error) {
      res.status(500).json({ message: "Failed to get customers" });
    }
  });
  app2.get("/api/customers/:id", async (req, res) => {
    try {
      const customer = await storage.getCustomer(req.params.id);
      if (!customer) {
        return res.status(404).json({ message: "Customer not found" });
      }
      res.json(customer);
    } catch (error) {
      res.status(500).json({ message: "Failed to get customer" });
    }
  });
  app2.post("/api/customers", async (req, res) => {
    try {
      const validatedData = insertCustomerSchema.parse(req.body);
      const existingCustomer = await storage.getCustomerByCode(validatedData.code);
      if (existingCustomer) {
        return res.status(409).json({ message: "Customer code already exists" });
      }
      if (validatedData.userId) {
        const user = await storage.getUser(validatedData.userId);
        if (!user) {
          return res.status(404).json({ message: "User not found" });
        }
      }
      const customer = await storage.createCustomer(validatedData);
      res.status(201).json(customer);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid customer data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create customer" });
    }
  });
  app2.put("/api/customers/:id", async (req, res) => {
    try {
      const existingCustomer = await storage.getCustomer(req.params.id);
      if (!existingCustomer) {
        return res.status(404).json({ message: "Customer not found" });
      }
      const validatedData = insertCustomerSchema.parse(req.body);
      if (validatedData.code !== existingCustomer.code) {
        const codeExists = await storage.getCustomerByCode(validatedData.code);
        if (codeExists) {
          return res.status(409).json({ message: "Customer code already exists" });
        }
      }
      if (validatedData.userId) {
        const user = await storage.getUser(validatedData.userId);
        if (!user) {
          return res.status(404).json({ message: "User not found" });
        }
      }
      const customer = await storage.updateCustomer(req.params.id, validatedData);
      res.json(customer);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid customer data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update customer" });
    }
  });
  app2.delete("/api/customers/:id", async (req, res) => {
    try {
      const customer = await storage.getCustomer(req.params.id);
      if (!customer) {
        return res.status(404).json({ message: "Customer not found" });
      }
      const customerProducts2 = await storage.getCustomerProductsByCustomer(req.params.id);
      if (customerProducts2.length > 0) {
        return res.status(409).json({ message: "Cannot delete customer with associated products" });
      }
      await storage.deleteCustomer(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete customer" });
    }
  });
  app2.get("/api/customer-products", async (_req, res) => {
    try {
      const customerProducts2 = await storage.getCustomerProducts();
      res.json(customerProducts2);
    } catch (error) {
      res.status(500).json({ message: "Failed to get customer products" });
    }
  });
  app2.get("/api/customers/:customerId/products", async (req, res) => {
    try {
      const customer = await storage.getCustomer(req.params.customerId);
      if (!customer) {
        return res.status(404).json({ message: "Customer not found" });
      }
      const customerProducts2 = await storage.getCustomerProductsByCustomer(req.params.customerId);
      res.json(customerProducts2);
    } catch (error) {
      res.status(500).json({ message: "Failed to get customer products" });
    }
  });
  app2.get("/api/customer-products/:id", async (req, res) => {
    try {
      const customerProduct = await storage.getCustomerProduct(parseInt(req.params.id));
      if (!customerProduct) {
        return res.status(404).json({ message: "Customer product not found" });
      }
      res.json(customerProduct);
    } catch (error) {
      res.status(500).json({ message: "Failed to get customer product" });
    }
  });
  app2.post("/api/customer-products", async (req, res) => {
    try {
      const validatedData = insertCustomerProductSchema.parse(req.body);
      const customer = await storage.getCustomer(validatedData.customerId);
      if (!customer) {
        return res.status(404).json({ message: "Customer not found" });
      }
      const category = await storage.getCategory(validatedData.categoryId);
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      const item = await storage.getItem(validatedData.itemId);
      if (!item) {
        return res.status(404).json({ message: "Item not found" });
      }
      if (validatedData.masterBatchId) {
        const masterBatch = await storage.getMasterBatch(validatedData.masterBatchId);
        if (!masterBatch) {
          return res.status(404).json({ message: "Master batch not found" });
        }
      }
      const customerProduct = await storage.createCustomerProduct(validatedData);
      res.status(201).json(customerProduct);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid customer product data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create customer product" });
    }
  });
  app2.put("/api/customer-products/:id", async (req, res) => {
    try {
      const existingCustomerProduct = await storage.getCustomerProduct(parseInt(req.params.id));
      if (!existingCustomerProduct) {
        return res.status(404).json({ message: "Customer product not found" });
      }
      const validatedData = insertCustomerProductSchema.parse(req.body);
      const customer = await storage.getCustomer(validatedData.customerId);
      if (!customer) {
        return res.status(404).json({ message: "Customer not found" });
      }
      const category = await storage.getCategory(validatedData.categoryId);
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      const item = await storage.getItem(validatedData.itemId);
      if (!item) {
        return res.status(404).json({ message: "Item not found" });
      }
      if (validatedData.masterBatchId) {
        const masterBatch = await storage.getMasterBatch(validatedData.masterBatchId);
        if (!masterBatch) {
          return res.status(404).json({ message: "Master batch not found" });
        }
      }
      const customerProduct = await storage.updateCustomerProduct(parseInt(req.params.id), validatedData);
      res.json(customerProduct);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid customer product data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update customer product" });
    }
  });
  app2.delete("/api/customer-products/:id", async (req, res) => {
    try {
      const customerProduct = await storage.getCustomerProduct(parseInt(req.params.id));
      if (!customerProduct) {
        return res.status(404).json({ message: "Customer product not found" });
      }
      await storage.deleteCustomerProduct(parseInt(req.params.id));
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete customer product" });
    }
  });
  app2.get("/api/orders", async (_req, res) => {
    try {
      const orders2 = await storage.getOrders();
      res.json(orders2);
    } catch (error) {
      res.status(500).json({ message: "Failed to get orders" });
    }
  });
  app2.get("/api/orders/:id", async (req, res) => {
    try {
      const order = await storage.getOrder(parseInt(req.params.id));
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      res.json(order);
    } catch (error) {
      res.status(500).json({ message: "Failed to get order" });
    }
  });
  app2.post("/api/orders", async (req, res) => {
    try {
      const validatedData = insertOrderSchema.parse(req.body);
      const customer = await storage.getCustomer(validatedData.customerId);
      if (!customer) {
        return res.status(404).json({ message: "Customer not found" });
      }
      if (validatedData.userId) {
        const user = await storage.getUser(validatedData.userId);
        if (!user) {
          return res.status(404).json({ message: "User not found" });
        }
      }
      const order = await storage.createOrder(validatedData);
      res.status(201).json(order);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid order data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create order" });
    }
  });
  app2.put("/api/orders/:id", async (req, res) => {
    try {
      const existingOrder = await storage.getOrder(parseInt(req.params.id));
      if (!existingOrder) {
        return res.status(404).json({ message: "Order not found" });
      }
      const statusSchema = z.object({
        status: z.enum(["pending", "processing", "completed"])
      });
      try {
        const { status } = statusSchema.parse(req.body);
        const updatedOrder = await storage.updateOrder(parseInt(req.params.id), { status });
        return res.json(updatedOrder);
      } catch (statusError) {
      }
      const validatedData = insertOrderSchema.parse(req.body);
      const customer = await storage.getCustomer(validatedData.customerId);
      if (!customer) {
        return res.status(404).json({ message: "Customer not found" });
      }
      if (validatedData.userId) {
        const user = await storage.getUser(validatedData.userId);
        if (!user) {
          return res.status(404).json({ message: "User not found" });
        }
      }
      const order = await storage.updateOrder(parseInt(req.params.id), validatedData);
      res.json(order);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid order data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update order" });
    }
  });
  app2.delete("/api/orders/:id", async (req, res) => {
    try {
      const orderId = parseInt(req.params.id);
      console.log(`Attempting to delete order with ID: ${orderId}`);
      const order = await storage.getOrder(orderId);
      if (!order) {
        console.log(`Order with ID ${orderId} not found`);
        return res.status(404).json({ message: "Order not found" });
      }
      const success = await storage.deleteOrder(orderId);
      if (success) {
        return res.status(200).json({
          success: true,
          message: `Order and all associated job orders deleted successfully`
        });
      } else {
        return res.status(500).json({ message: "Failed to delete order" });
      }
    } catch (error) {
      console.error("Error deleting order:", error);
      return res.status(500).json({
        message: "Failed to delete order",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  app2.get("/api/job-orders", async (_req, res) => {
    try {
      const jobOrders2 = await storage.getJobOrders();
      res.json(jobOrders2);
    } catch (error) {
      res.status(500).json({ message: "Failed to get job orders" });
    }
  });
  app2.get("/api/orders/:orderId/job-orders", async (req, res) => {
    try {
      const order = await storage.getOrder(parseInt(req.params.orderId));
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      const jobOrders2 = await storage.getJobOrdersByOrder(parseInt(req.params.orderId));
      res.json(jobOrders2);
    } catch (error) {
      res.status(500).json({ message: "Failed to get job orders" });
    }
  });
  app2.get("/api/job-orders/:id", async (req, res) => {
    try {
      const jobOrder = await storage.getJobOrder(parseInt(req.params.id));
      if (!jobOrder) {
        return res.status(404).json({ message: "Job order not found" });
      }
      res.json(jobOrder);
    } catch (error) {
      res.status(500).json({ message: "Failed to get job order" });
    }
  });
  app2.post("/api/job-orders", async (req, res) => {
    try {
      const validatedData = insertJobOrderSchema.parse(req.body);
      const order = await storage.getOrder(validatedData.orderId);
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      const customerProduct = await storage.getCustomerProduct(validatedData.customerProductId);
      if (!customerProduct) {
        return res.status(404).json({ message: "Customer product not found" });
      }
      const jobOrder = await storage.createJobOrder(validatedData);
      res.status(201).json(jobOrder);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid job order data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create job order" });
    }
  });
  app2.put("/api/job-orders/:id", async (req, res) => {
    try {
      const existingJobOrder = await storage.getJobOrder(parseInt(req.params.id));
      if (!existingJobOrder) {
        return res.status(404).json({ message: "Job order not found" });
      }
      if (req.body && typeof req.body === "object" && "status" in req.body) {
        const statusSchema = z.object({
          status: z.enum(["pending", "in_progress", "extrusion_completed", "completed", "cancelled"])
        });
        try {
          const { status } = statusSchema.parse(req.body);
          const updatedJobOrder = await storage.updateJobOrder(parseInt(req.params.id), { status });
          return res.json(updatedJobOrder);
        } catch (statusError) {
        }
      }
      const validatedData = insertJobOrderSchema.parse(req.body);
      const order = await storage.getOrder(validatedData.orderId);
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      const customerProduct = await storage.getCustomerProduct(validatedData.customerProductId);
      if (!customerProduct) {
        return res.status(404).json({ message: "Customer product not found" });
      }
      const jobOrder = await storage.updateJobOrder(parseInt(req.params.id), validatedData);
      res.json(jobOrder);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid job order data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update job order" });
    }
  });
  app2.delete("/api/job-orders/:id", async (req, res) => {
    try {
      const jobOrder = await storage.getJobOrder(parseInt(req.params.id));
      if (!jobOrder) {
        return res.status(404).json({ message: "Job order not found" });
      }
      await storage.deleteJobOrder(parseInt(req.params.id));
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete job order" });
    }
  });
  app2.get("/api/rolls", async (_req, res) => {
    try {
      const rolls2 = await storage.getRolls();
      res.json(rolls2);
    } catch (error) {
      res.status(500).json({ message: "Failed to get rolls" });
    }
  });
  app2.get("/api/job-orders/:jobOrderId/rolls", async (req, res) => {
    try {
      const jobOrder = await storage.getJobOrder(parseInt(req.params.jobOrderId));
      if (!jobOrder) {
        return res.status(404).json({ message: "Job order not found" });
      }
      const rolls2 = await storage.getRollsByJobOrder(parseInt(req.params.jobOrderId));
      res.json(rolls2);
    } catch (error) {
      res.status(500).json({ message: "Failed to get rolls" });
    }
  });
  app2.get("/api/rolls/stage/:stage", async (req, res) => {
    try {
      const stage = req.params.stage;
      if (!["extrusion", "printing", "cutting", "completed"].includes(stage)) {
        return res.status(400).json({ message: "Invalid stage" });
      }
      const rolls2 = await storage.getRollsByStage(stage);
      res.json(rolls2);
    } catch (error) {
      res.status(500).json({ message: "Failed to get rolls" });
    }
  });
  app2.get("/api/rolls/:id", async (req, res) => {
    try {
      const roll = await storage.getRoll(req.params.id);
      if (!roll) {
        return res.status(404).json({ message: "Roll not found" });
      }
      res.json(roll);
    } catch (error) {
      res.status(500).json({ message: "Failed to get roll" });
    }
  });
  app2.post("/api/rolls", async (req, res) => {
    try {
      console.log("Receiving roll creation request with data:", req.body);
      const validatedData = createRollSchema.parse(req.body);
      console.log("Validated roll data:", validatedData);
      const jobOrder = await storage.getJobOrder(validatedData.jobOrderId);
      if (!jobOrder) {
        console.error(`Job order not found with ID: ${validatedData.jobOrderId}`);
        return res.status(404).json({ message: "Job order not found" });
      }
      console.log("Found job order:", jobOrder);
      const existingRolls = await storage.getRollsByJobOrder(validatedData.jobOrderId);
      const nextSerialNumber = (existingRolls.length + 1).toString();
      console.log(`Next serial number: ${nextSerialNumber}, existing rolls: ${existingRolls.length}`);
      const currentUserId = "00U1";
      const paddedJobOrderId = String(validatedData.jobOrderId).padStart(4, "0");
      const paddedSerialNumber = nextSerialNumber.padStart(3, "0");
      const rollData = {
        ...validatedData,
        serialNumber: paddedSerialNumber,
        id: `EX-${paddedJobOrderId}-${paddedSerialNumber}`,
        createdById: currentUserId,
        createdAt: /* @__PURE__ */ new Date()
      };
      console.log("Roll data to be inserted:", rollData);
      const roll = await storage.createRoll(rollData);
      console.log("Successfully created roll:", roll);
      res.status(201).json(roll);
    } catch (error) {
      console.error("Error creating roll:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid roll data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create roll" });
    }
  });
  app2.put("/api/rolls/:id", async (req, res) => {
    try {
      console.log(`Attempting to update roll ID: ${req.params.id} with data:`, req.body);
      const existingRoll = await storage.getRoll(req.params.id);
      if (!existingRoll) {
        console.log(`Roll with ID ${req.params.id} not found`);
        return res.status(404).json({ message: "Roll not found" });
      }
      console.log(`Found existing roll:`, existingRoll);
      const statusStageSchema = z.object({
        status: z.enum(["pending", "processing", "completed"]).optional(),
        currentStage: z.enum(["extrusion", "printing", "cutting", "completed"]).optional(),
        extrudingQty: z.number().optional(),
        printingQty: z.number().optional(),
        cuttingQty: z.number().optional(),
        wasteQty: z.number().optional(),
        wastePercentage: z.number().optional(),
        createdById: z.string().optional(),
        printedById: z.string().optional(),
        cutById: z.string().optional()
      });
      try {
        console.log("Attempting to validate as a stage/status update");
        const updateData = statusStageSchema.parse(req.body);
        console.log("Validation succeeded, updating roll with:", updateData);
        if (existingRoll.currentStage === "extrusion" && updateData.currentStage === "printing") {
          console.log("Adding printedAt date to update data");
          updateData.printedAt = /* @__PURE__ */ new Date();
        }
        if (existingRoll.currentStage === "printing" && updateData.currentStage === "cutting") {
          console.log("Adding cutAt date to update data");
          updateData.cutAt = /* @__PURE__ */ new Date();
        }
        const updatedRoll = await storage.updateRoll(req.params.id, updateData);
        console.log("Roll successfully updated:", updatedRoll);
        return res.json(updatedRoll);
      } catch (statusError) {
        console.log("Status/stage validation failed:", statusError);
      }
      const validatedData = insertRollSchema.parse(req.body);
      const jobOrder = await storage.getJobOrder(validatedData.jobOrderId);
      if (!jobOrder) {
        return res.status(404).json({ message: "Job order not found" });
      }
      const roll = await storage.updateRoll(req.params.id, validatedData);
      res.json(roll);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid roll data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update roll" });
    }
  });
  app2.delete("/api/rolls/:id", async (req, res) => {
    try {
      const roll = await storage.getRoll(req.params.id);
      if (!roll) {
        return res.status(404).json({ message: "Roll not found" });
      }
      await storage.deleteRoll(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete roll" });
    }
  });
  app2.get("/api/raw-materials", async (_req, res) => {
    try {
      const rawMaterials2 = await storage.getRawMaterials();
      res.json(rawMaterials2);
    } catch (error) {
      res.status(500).json({ message: "Failed to get raw materials" });
    }
  });
  app2.get("/api/raw-materials/:id", async (req, res) => {
    try {
      const rawMaterial = await storage.getRawMaterial(parseInt(req.params.id));
      if (!rawMaterial) {
        return res.status(404).json({ message: "Raw material not found" });
      }
      res.json(rawMaterial);
    } catch (error) {
      res.status(500).json({ message: "Failed to get raw material" });
    }
  });
  app2.post("/api/raw-materials", async (req, res) => {
    try {
      const validatedData = insertRawMaterialSchema.parse(req.body);
      const rawMaterial = await storage.createRawMaterial(validatedData);
      res.status(201).json(rawMaterial);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid raw material data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create raw material" });
    }
  });
  app2.put("/api/raw-materials/:id", async (req, res) => {
    try {
      const existingRawMaterial = await storage.getRawMaterial(parseInt(req.params.id));
      if (!existingRawMaterial) {
        return res.status(404).json({ message: "Raw material not found" });
      }
      const validatedData = insertRawMaterialSchema.parse(req.body);
      const rawMaterial = await storage.updateRawMaterial(parseInt(req.params.id), validatedData);
      res.json(rawMaterial);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid raw material data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update raw material" });
    }
  });
  app2.delete("/api/raw-materials/:id", async (req, res) => {
    try {
      const rawMaterial = await storage.getRawMaterial(parseInt(req.params.id));
      if (!rawMaterial) {
        return res.status(404).json({ message: "Raw material not found" });
      }
      await storage.deleteRawMaterial(parseInt(req.params.id));
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete raw material" });
    }
  });
  app2.get("/api/final-products", async (_req, res) => {
    try {
      const finalProducts2 = await storage.getFinalProducts();
      res.json(finalProducts2);
    } catch (error) {
      res.status(500).json({ message: "Failed to get final products" });
    }
  });
  app2.get("/api/final-products/:id", async (req, res) => {
    try {
      const finalProduct = await storage.getFinalProduct(parseInt(req.params.id));
      if (!finalProduct) {
        return res.status(404).json({ message: "Final product not found" });
      }
      res.json(finalProduct);
    } catch (error) {
      res.status(500).json({ message: "Failed to get final product" });
    }
  });
  app2.post("/api/final-products", async (req, res) => {
    try {
      const validatedData = insertFinalProductSchema.parse(req.body);
      const jobOrder = await storage.getJobOrder(validatedData.jobOrderId);
      if (!jobOrder) {
        return res.status(404).json({ message: "Job order not found" });
      }
      const finalProduct = await storage.createFinalProduct(validatedData);
      res.status(201).json(finalProduct);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid final product data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create final product" });
    }
  });
  app2.put("/api/final-products/:id", async (req, res) => {
    try {
      const existingFinalProduct = await storage.getFinalProduct(parseInt(req.params.id));
      if (!existingFinalProduct) {
        return res.status(404).json({ message: "Final product not found" });
      }
      const validatedData = insertFinalProductSchema.parse(req.body);
      const jobOrder = await storage.getJobOrder(validatedData.jobOrderId);
      if (!jobOrder) {
        return res.status(404).json({ message: "Job order not found" });
      }
      const finalProduct = await storage.updateFinalProduct(parseInt(req.params.id), validatedData);
      res.json(finalProduct);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid final product data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update final product" });
    }
  });
  app2.delete("/api/final-products/:id", async (req, res) => {
    try {
      const finalProduct = await storage.getFinalProduct(parseInt(req.params.id));
      if (!finalProduct) {
        return res.status(404).json({ message: "Final product not found" });
      }
      await storage.deleteFinalProduct(parseInt(req.params.id));
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete final product" });
    }
  });
  app2.get("/api/quality-check-types", async (_req, res) => {
    try {
      const qualityCheckTypes2 = await storage.getQualityCheckTypes();
      res.json(qualityCheckTypes2);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch quality check types" });
    }
  });
  app2.get("/api/quality-check-types/stage/:stage", async (req, res) => {
    try {
      const stage = req.params.stage;
      const qualityCheckTypes2 = await storage.getQualityCheckTypesByStage(stage);
      res.json(qualityCheckTypes2);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch quality check types by stage" });
    }
  });
  app2.get("/api/quality-check-types/:id", async (req, res) => {
    try {
      const id = req.params.id;
      const qualityCheckType = await storage.getQualityCheckType(id);
      if (!qualityCheckType) {
        return res.status(404).json({ message: "Quality check type not found" });
      }
      res.json(qualityCheckType);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch quality check type" });
    }
  });
  app2.post("/api/quality-check-types", async (req, res) => {
    try {
      const qualityCheckType = await storage.createQualityCheckType(req.body);
      res.status(201).json(qualityCheckType);
    } catch (error) {
      res.status(500).json({ message: "Failed to create quality check type" });
    }
  });
  app2.patch("/api/quality-check-types/:id", async (req, res) => {
    try {
      const id = req.params.id;
      const qualityCheckType = await storage.updateQualityCheckType(id, req.body);
      if (!qualityCheckType) {
        return res.status(404).json({ message: "Quality check type not found" });
      }
      res.json(qualityCheckType);
    } catch (error) {
      res.status(500).json({ message: "Failed to update quality check type" });
    }
  });
  app2.delete("/api/quality-check-types/:id", async (req, res) => {
    try {
      const id = req.params.id;
      const success = await storage.deleteQualityCheckType(id);
      if (!success) {
        return res.status(404).json({ message: "Quality check type not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete quality check type" });
    }
  });
  app2.get("/api/quality-checks", async (_req, res) => {
    try {
      const qualityChecks2 = await storage.getQualityChecks();
      res.json(qualityChecks2);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch quality checks" });
    }
  });
  app2.get("/api/quality-checks/roll/:rollId", async (req, res) => {
    try {
      const rollId = req.params.rollId;
      const qualityChecks2 = await storage.getQualityChecksByRoll(rollId);
      res.json(qualityChecks2);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch quality checks by roll" });
    }
  });
  app2.get("/api/quality-checks/job-order/:jobOrderId", async (req, res) => {
    try {
      const jobOrderId = parseInt(req.params.jobOrderId);
      if (isNaN(jobOrderId)) {
        return res.status(400).json({ message: "Invalid job order ID" });
      }
      const qualityChecks2 = await storage.getQualityChecksByJobOrder(jobOrderId);
      res.json(qualityChecks2);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch quality checks by job order" });
    }
  });
  app2.get("/api/quality-checks/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid quality check ID" });
      }
      const qualityCheck = await storage.getQualityCheck(id);
      if (!qualityCheck) {
        return res.status(404).json({ message: "Quality check not found" });
      }
      res.json(qualityCheck);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch quality check" });
    }
  });
  app2.post("/api/quality-checks", async (req, res) => {
    try {
      const qualityCheck = await storage.createQualityCheck(req.body);
      res.status(201).json(qualityCheck);
    } catch (error) {
      res.status(500).json({ message: "Failed to create quality check" });
    }
  });
  app2.patch("/api/quality-checks/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid quality check ID" });
      }
      const qualityCheck = await storage.updateQualityCheck(id, req.body);
      if (!qualityCheck) {
        return res.status(404).json({ message: "Quality check not found" });
      }
      res.json(qualityCheck);
    } catch (error) {
      res.status(500).json({ message: "Failed to update quality check" });
    }
  });
  app2.delete("/api/quality-checks/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid quality check ID" });
      }
      const success = await storage.deleteQualityCheck(id);
      if (!success) {
        return res.status(404).json({ message: "Quality check not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete quality check" });
    }
  });
  app2.get("/api/corrective-actions", async (_req, res) => {
    try {
      const correctiveActions2 = await storage.getCorrectiveActions();
      res.json(correctiveActions2);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch corrective actions" });
    }
  });
  app2.get("/api/corrective-actions/quality-check/:qualityCheckId", async (req, res) => {
    try {
      const qualityCheckId = parseInt(req.params.qualityCheckId);
      if (isNaN(qualityCheckId)) {
        return res.status(400).json({ message: "Invalid quality check ID" });
      }
      const correctiveActions2 = await storage.getCorrectiveActionsByQualityCheck(qualityCheckId);
      res.json(correctiveActions2);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch corrective actions by quality check" });
    }
  });
  app2.get("/api/corrective-actions/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid corrective action ID" });
      }
      const correctiveAction = await storage.getCorrectiveAction(id);
      if (!correctiveAction) {
        return res.status(404).json({ message: "Corrective action not found" });
      }
      res.json(correctiveAction);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch corrective action" });
    }
  });
  app2.post("/api/corrective-actions", async (req, res) => {
    try {
      const correctiveAction = await storage.createCorrectiveAction(req.body);
      res.status(201).json(correctiveAction);
    } catch (error) {
      res.status(500).json({ message: "Failed to create corrective action" });
    }
  });
  app2.patch("/api/corrective-actions/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid corrective action ID" });
      }
      const correctiveAction = await storage.updateCorrectiveAction(id, req.body);
      if (!correctiveAction) {
        return res.status(404).json({ message: "Corrective action not found" });
      }
      res.json(correctiveAction);
    } catch (error) {
      res.status(500).json({ message: "Failed to update corrective action" });
    }
  });
  app2.delete("/api/corrective-actions/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid corrective action ID" });
      }
      const success = await storage.deleteCorrectiveAction(id);
      if (!success) {
        return res.status(404).json({ message: "Corrective action not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete corrective action" });
    }
  });
  app2.post("/api/init-demo-data", async (_req, res) => {
    try {
      const { initializeDemoData: initializeDemoData2 } = await Promise.resolve().then(() => (init_demo_data(), demo_data_exports));
      const result = await initializeDemoData2(storage);
      if (result.success) {
        res.status(200).json({ message: "Demo data initialized successfully" });
      } else {
        throw result.error;
      }
    } catch (error) {
      console.error("Failed to initialize demo data:", error);
      res.status(500).json({ message: "Failed to initialize demo data", error });
    }
  });
  app2.post("/api/import-csv", async (req, res) => {
    try {
      const { entityType } = req.body;
      if (!req.files || !req.files.file) {
        return res.status(400).json({ message: "No file was uploaded" });
      }
      if (!entityType) {
        return res.status(400).json({ message: "Entity type is required" });
      }
      const file = req.files.file;
      const csvData = file.data.toString();
      const { importFromCSV: importFromCSV2 } = await Promise.resolve().then(() => (init_import_utils(), import_utils_exports));
      const result = await importFromCSV2(entityType, csvData, storage);
      if (result.success === true && "created" in result) {
        res.status(200).json({
          message: "CSV data imported successfully",
          created: result.created,
          updated: result.updated,
          failed: result.failed,
          errors: result.errors && result.errors.length > 0 ? result.errors : void 0
        });
      } else if (result.success === false && "message" in result) {
        res.status(400).json({
          message: result.message,
          errors: result.errors || []
        });
      } else {
        res.status(500).json({ message: "Unknown import result format" });
      }
    } catch (error) {
      console.error("Failed to import CSV data:", error);
      res.status(500).json({ message: "Failed to import CSV data", error: error.message });
    }
  });
  app2.get("/api/sms-messages", async (_req, res) => {
    try {
      const messages = await storage.getSmsMessages();
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Failed to get SMS messages" });
    }
  });
  app2.get("/api/orders/:orderId/sms-messages", async (req, res) => {
    try {
      const orderId = parseInt(req.params.orderId);
      if (isNaN(orderId)) {
        return res.status(400).json({ message: "Invalid order ID" });
      }
      const order = await storage.getOrder(orderId);
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      const messages = await storage.getSmsMessagesByOrder(orderId);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Failed to get SMS messages" });
    }
  });
  app2.get("/api/job-orders/:jobOrderId/sms-messages", async (req, res) => {
    try {
      const jobOrderId = parseInt(req.params.jobOrderId);
      if (isNaN(jobOrderId)) {
        return res.status(400).json({ message: "Invalid job order ID" });
      }
      const jobOrder = await storage.getJobOrder(jobOrderId);
      if (!jobOrder) {
        return res.status(404).json({ message: "Job order not found" });
      }
      const messages = await storage.getSmsMessagesByJobOrder(jobOrderId);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Failed to get SMS messages" });
    }
  });
  app2.get("/api/customers/:customerId/sms-messages", async (req, res) => {
    try {
      const customerId = req.params.customerId;
      const customer = await storage.getCustomer(customerId);
      if (!customer) {
        return res.status(404).json({ message: "Customer not found" });
      }
      const messages = await storage.getSmsMessagesByCustomer(customerId);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Failed to get SMS messages" });
    }
  });
  app2.get("/api/sms-messages/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid SMS message ID" });
      }
      const message = await storage.getSmsMessage(id);
      if (!message) {
        return res.status(404).json({ message: "SMS message not found" });
      }
      res.json(message);
    } catch (error) {
      res.status(500).json({ message: "Failed to get SMS message" });
    }
  });
  app2.post("/api/sms-messages", async (req, res) => {
    try {
      const validatedData = insertSmsMessageSchema.parse(req.body);
      const { SmsService: SmsService2 } = await Promise.resolve().then(() => (init_sms_service(), sms_service_exports));
      let result;
      if (validatedData.messageType === "order_notification" && validatedData.orderId) {
        result = await SmsService2.sendOrderNotification(
          validatedData.orderId,
          validatedData.recipientPhone,
          validatedData.message,
          validatedData.sentBy || null,
          validatedData.recipientName || null,
          validatedData.customerId || null
        );
      } else if (validatedData.messageType === "status_update" && validatedData.jobOrderId) {
        result = await SmsService2.sendJobOrderUpdate(
          validatedData.jobOrderId,
          validatedData.recipientPhone,
          validatedData.message,
          validatedData.sentBy || null,
          validatedData.recipientName || null,
          validatedData.customerId || null
        );
      } else {
        result = await SmsService2.sendCustomMessage(
          validatedData.recipientPhone,
          validatedData.message,
          validatedData.sentBy || null,
          validatedData.recipientName || null,
          validatedData.customerId || null,
          validatedData.orderId || null,
          validatedData.jobOrderId || null
        );
      }
      res.status(201).json(result);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid SMS message data", errors: error.errors });
      }
      res.status(500).json({ message: `Failed to send SMS message: ${error.message}` });
    }
  });
  app2.delete("/api/sms-messages/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid SMS message ID" });
      }
      const message = await storage.getSmsMessage(id);
      if (!message) {
        return res.status(404).json({ message: "SMS message not found" });
      }
      await storage.deleteSmsMessage(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete SMS message" });
    }
  });
  app2.get("/api/mix-materials", requireAuth, async (_req, res) => {
    try {
      const mixMaterials2 = await storage.getMixMaterials();
      const mixIds = mixMaterials2.map((mix) => mix.id);
      const mixMachinesMap = /* @__PURE__ */ new Map();
      for (const mixId of mixIds) {
        const mixMachines2 = await storage.getMixMachinesByMixId(mixId);
        const machineIds = mixMachines2.map((mm) => mm.machineId);
        mixMachinesMap.set(mixId, machineIds);
      }
      const result = mixMaterials2.map((mix) => ({
        ...mix,
        machines: mixMachinesMap.get(mix.id) || []
      }));
      res.json(result);
    } catch (error) {
      res.status(500).json({ message: "Failed to get mix materials" });
    }
  });
  app2.get("/api/mix-materials/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      const mixMaterial = await storage.getMixMaterial(id);
      if (!mixMaterial) {
        return res.status(404).json({ message: "Mix material not found" });
      }
      const mixMachines2 = await storage.getMixMachinesByMixId(id);
      const machineIds = mixMachines2.map((mm) => mm.machineId);
      const result = {
        ...mixMaterial,
        machines: machineIds
      };
      res.json(result);
    } catch (error) {
      res.status(500).json({ message: "Failed to get mix material" });
    }
  });
  app2.post("/api/mix-materials", requireAuth, async (req, res) => {
    try {
      const { machineIds, ...mixData } = req.body;
      const validatedData = insertMixMaterialSchema.parse(mixData);
      if (validatedData.orderId) {
        const order = await storage.getOrder(validatedData.orderId);
        if (!order) {
          return res.status(404).json({ message: "Order not found" });
        }
      }
      if (req.user) {
        validatedData.mixPerson = req.user.id;
      } else {
        return res.status(401).json({ message: "Authentication required" });
      }
      const mixMaterial = await storage.createMixMaterial(validatedData);
      if (machineIds && Array.isArray(machineIds) && machineIds.length > 0) {
        for (const machineId of machineIds) {
          const machine = await storage.getMachine(machineId);
          if (!machine) {
            console.warn(`Machine with ID ${machineId} not found. Skipping.`);
            continue;
          }
          await storage.createMixMachine({
            mixId: mixMaterial.id,
            machineId
          });
        }
      }
      const result = {
        ...mixMaterial,
        machines: machineIds || []
      };
      res.status(201).json(result);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid mix material data", errors: error.errors });
      }
      console.error("Error creating mix material:", error);
      res.status(500).json({ message: "Failed to create mix material" });
    }
  });
  app2.put("/api/mix-materials/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      const existingMixMaterial = await storage.getMixMaterial(id);
      if (!existingMixMaterial) {
        return res.status(404).json({ message: "Mix material not found" });
      }
      const { machineIds, ...mixData } = req.body;
      const validatedData = insertMixMaterialSchema.parse(mixData);
      if (validatedData.orderId) {
        const order = await storage.getOrder(validatedData.orderId);
        if (!order) {
          return res.status(404).json({ message: "Order not found" });
        }
      }
      const updatedMixMaterial = await storage.updateMixMaterial(id, validatedData);
      if (machineIds !== void 0) {
        await storage.deleteMixMachinesByMixId(id);
        if (Array.isArray(machineIds) && machineIds.length > 0) {
          for (const machineId of machineIds) {
            const machine = await storage.getMachine(machineId);
            if (!machine) {
              console.warn(`Machine with ID ${machineId} not found. Skipping.`);
              continue;
            }
            await storage.createMixMachine({
              mixId: id,
              machineId
            });
          }
        }
      }
      const mixMachines2 = await storage.getMixMachinesByMixId(id);
      const machineIdsArray = mixMachines2.map((mm) => mm.machineId);
      const result = {
        ...updatedMixMaterial,
        machines: machineIdsArray
      };
      res.json(result);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid mix material data", errors: error.errors });
      }
      console.error("Error updating mix material:", error);
      res.status(500).json({ message: "Failed to update mix material" });
    }
  });
  app2.delete("/api/mix-materials/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      const mixMaterial = await storage.getMixMaterial(id);
      if (!mixMaterial) {
        return res.status(404).json({ message: "Mix material not found" });
      }
      await storage.deleteMixMaterial(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete mix material" });
    }
  });
  app2.get("/api/mix-items", requireAuth, async (_req, res) => {
    try {
      const mixItems2 = await storage.getMixItems();
      res.json(mixItems2);
    } catch (error) {
      res.status(500).json({ message: "Failed to get mix items" });
    }
  });
  app2.get("/api/mix-materials/:mixId/items", requireAuth, async (req, res) => {
    try {
      const mixId = parseInt(req.params.mixId);
      if (isNaN(mixId)) {
        return res.status(400).json({ message: "Invalid mix ID format" });
      }
      const mixMaterial = await storage.getMixMaterial(mixId);
      if (!mixMaterial) {
        return res.status(404).json({ message: "Mix material not found" });
      }
      const mixItems2 = await storage.getMixItemsByMix(mixId);
      res.json(mixItems2);
    } catch (error) {
      res.status(500).json({ message: "Failed to get mix items" });
    }
  });
  app2.get("/api/mix-items/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      const mixItem = await storage.getMixItem(id);
      if (!mixItem) {
        return res.status(404).json({ message: "Mix item not found" });
      }
      res.json(mixItem);
    } catch (error) {
      res.status(500).json({ message: "Failed to get mix item" });
    }
  });
  app2.post("/api/mix-items", requireAuth, async (req, res) => {
    try {
      const validatedData = insertMixItemSchema.parse(req.body);
      const mixMaterial = await storage.getMixMaterial(validatedData.mixId);
      if (!mixMaterial) {
        return res.status(404).json({ message: "Mix material not found" });
      }
      const rawMaterial = await storage.getRawMaterial(validatedData.rawMaterialId);
      if (!rawMaterial) {
        return res.status(404).json({ message: "Raw material not found" });
      }
      if (validatedData.quantity <= 0) {
        return res.status(400).json({ message: "Quantity must be greater than zero" });
      }
      if (rawMaterial.quantity === null || rawMaterial.quantity < validatedData.quantity) {
        return res.status(400).json({
          message: `Insufficient quantity of raw material ${rawMaterial.name}`,
          available: rawMaterial.quantity,
          requested: validatedData.quantity
        });
      }
      const mixItem = await storage.createMixItem(validatedData);
      res.status(201).json(mixItem);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid mix item data", errors: error.errors });
      }
      if (error instanceof Error) {
        return res.status(400).json({ message: error.message });
      }
      res.status(500).json({ message: "Failed to create mix item" });
    }
  });
  app2.put("/api/mix-items/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      const existingMixItem = await storage.getMixItem(id);
      if (!existingMixItem) {
        return res.status(404).json({ message: "Mix item not found" });
      }
      const { quantity } = req.body;
      if (quantity === void 0) {
        return res.status(400).json({ message: "Quantity is required" });
      }
      if (quantity <= 0) {
        return res.status(400).json({ message: "Quantity must be greater than zero" });
      }
      const updatedMixItem = await storage.updateMixItem(id, { quantity });
      res.json(updatedMixItem);
    } catch (error) {
      if (error instanceof Error) {
        return res.status(400).json({ message: error.message });
      }
      res.status(500).json({ message: "Failed to update mix item" });
    }
  });
  app2.delete("/api/mix-items/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      const mixItem = await storage.getMixItem(id);
      if (!mixItem) {
        return res.status(404).json({ message: "Mix item not found" });
      }
      await storage.deleteMixItem(id);
      res.status(204).send();
    } catch (error) {
      if (error instanceof Error) {
        return res.status(400).json({ message: error.message });
      }
      res.status(500).json({ message: "Failed to delete mix item" });
    }
  });
  const httpServer = createServer(app2);
  return httpServer;
}

// server/vite.ts
import express from "express";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { createServer as createViteServer, createLogger } from "vite";
import { nanoid } from "nanoid";
var __filename = fileURLToPath(import.meta.url);
var __dirname = path.dirname(__filename);
var viteLogger = createLogger();
function log(message, source = "express") {
  const formattedTime = (/* @__PURE__ */ new Date()).toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true
  });
  console.log(`${formattedTime} [${source}] ${message}`);
}
async function setupVite(app2, server) {
  const serverOptions = {
    middlewareMode: true,
    hmr: { server },
    allowedHosts: [true]
  };
  const vite = await createViteServer({
    server: serverOptions,
    configFile: path.resolve(__dirname, "../vite.config.ts"),
    appType: "custom"
  });
  app2.use(vite.middlewares);
  app2.use("*", async (req, res, next) => {
    const url = req.originalUrl;
    try {
      const clientTemplate = path.resolve(__dirname, "..", "client", "index.html");
      let template = await fs.promises.readFile(clientTemplate, "utf-8");
      template = template.replace(
        `src="/src/main.tsx"`,
        `src="/src/main.tsx?v=${nanoid()}"`
      );
      const page = await vite.transformIndexHtml(url, template);
      res.status(200).set({ "Content-Type": "text/html" }).end(page);
    } catch (e) {
      vite.ssrFixStacktrace(e);
      next(e);
    }
  });
}
function serveStatic(app2) {
  const distPath = path.resolve(__dirname, "public");
  if (!fs.existsSync(distPath)) {
    throw new Error(
      `Could not find the build directory: ${distPath}, make sure to build the client first`
    );
  }
  app2.use(express.static(distPath));
  app2.use("*", (_req, res) => {
    res.sendFile(path.resolve(distPath, "index.html"));
  });
}

// server/index.ts
dotenv2.config();
var app = express2();
app.use(express2.json());
app.use(express2.urlencoded({ extended: false }));
app.use(fileUpload({
  limits: { fileSize: 5 * 1024 * 1024 },
  // 5MB max file size
  useTempFiles: false,
  abortOnLimit: true,
  createParentPath: true,
  safeFileNames: true,
  preserveExtension: true
}));
app.use((req, res, next) => {
  const start = Date.now();
  const path2 = req.path;
  let capturedJsonResponse = void 0;
  const originalResJson = res.json;
  res.json = function(bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };
  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path2.startsWith("/api")) {
      let logLine = `${req.method} ${path2} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }
      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "\u2026";
      }
      log(logLine);
    }
  });
  next();
});
(async () => {
  const server = await registerRoutes(app);
  app.use((err, _req, res, _next) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";
    res.status(status).json({ message });
    throw err;
  });
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }
  const port = 5e3;
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true
  }, () => {
    log(`serving on port ${port}`);
  });
})();
